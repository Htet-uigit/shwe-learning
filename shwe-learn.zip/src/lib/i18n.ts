
export type LanguageCode = 'en' | 'my';

export interface Translations {
  [key: string]: {
    [lang in LanguageCode]: string;
  };
}

export const translations: Translations = {
  appName: {
    en: 'Shwe Learn',
    my: 'ရွှေသင်ယူမှု'
  },
  teacherDashboard: {
    en: 'Teacher Dashboard',
    my: 'ဆရာဒက်ရှ်ဘုတ်'
  },
  studentDashboard: {
    en: 'Student Dashboard',
    my: 'ကျောင်းသားဒက်ရှ်ဘုတ်'
  },
  myCourses: {
    en: 'My Courses',
    my: 'ကျွန်ုပ်၏သင်တန်းများ'
  },
  studentPassport: {
    en: 'Student Passport',
    my: 'ကျောင်းသားပတ်စပို့'
  },
  scanQR: {
    en: 'Scan QR Code',
    my: 'QR ကုဒ်ဖတ်ရန်'
  },
  generateQR: {
    en: 'Generate Passport QR',
    my: 'ပတ်စပို့ QR ထုတ်ရန်'
  },
  exportCurriculum: {
    en: 'Export Curriculum',
    my: 'သင်ရိုးညွှန်းတမ်းထုတ်ရန်'
  },
  aiChatbot: {
    en: 'AI Education Assistant',
    my: 'AI ပညာရေးလက်ထောက်'
  },
  lessonPlan: {
    en: 'Lesson Plan',
    my: 'သင်ခန်းစာအစီအစဉ်'
  },
  radioScript: {
    en: 'Radio Script',
    my: 'ရေဒီယိုဇာတ်ညွှန်း'
  },
  resilienceChecklist: {
    en: 'Resilience Checklist',
    my: 'ကြံ့ကြံ့ခံနိုင်မှုစစ်ဆေးချက်'
  },
  video: {
    en: 'Video',
    my: 'ဗီဒီယို'
  },
  audio: {
    en: 'Audio',
    my: 'အသံ'
  },
  pdf: {
    en: 'PDF',
    my: 'PDF'
  },
  discussion: {
    en: 'Discussion',
    my: 'ဆွေးနွေးချက်'
  },
  quiz: {
    en: 'Quiz',
    my: 'ပဟေဠိ'
  },
  progress: {
    en: 'Progress',
    my: 'တိုးတက်မှု'
  },
  complete: {
    en: 'Complete',
    my: 'ပြီးမြောက်သည်'
  },
  generate: {
    en: 'Generate',
    my: 'ထုတ်လုပ်ရန်'
  },
  topicPlaceholder: {
    en: 'Enter topic (e.g., Water Cycle)',
    my: 'ခေါင်းစဉ်ရိုက်ထည့်ပါ (ဥပမာ- ရေစက်ဝန်း)'
  },
  createLesson: {
    en: 'Create Lesson',
    my: 'သင်ခန်းစာအသစ်ဖန်တီးပါ'
  },
  createLessonDesc: {
    en: 'Generate localized, zero-resource curriculum for your students.',
    my: 'သင့်ကျောင်းသားများအတွက် ဒေသန္တရအခြေပြု၊ အရင်းအမြစ်မဲ့ သင်ရိုးညွှန်းတမ်းကို ထုတ်လုပ်ပါ။'
  },
  lessonTopic: {
    en: 'Lesson Topic',
    my: 'သင်ခန်းစာခေါင်းစဉ်'
  },
  zeroResourceContext: {
    en: 'Zero-Resource Context',
    my: 'အရင်းအမြစ်မဲ့ အခြေအနေ'
  },
  zeroResourceDesc: {
    en: 'Upload a photo of local materials (stones, leaves, sticks) to incorporate them into the lesson.',
    my: 'သင်ခန်းစာတွင် ထည့်သွင်းရန် ဒေသထွက်ပစ္စည်းများ (ကျောက်ခဲ၊ သစ်ရွက်၊ သစ်ကိုင်း) ဓာတ်ပုံကို တင်ပါ။'
  },
  clickToUpload: {
    en: 'Click to upload a photo',
    my: 'ဓာတ်ပုံတင်ရန် နှိပ်ပါ'
  },
  uploadLimit: {
    en: 'PNG, JPG up to 10MB',
    my: 'PNG, JPG (အများဆုံး 10MB)'
  },
  removeImage: {
    en: 'Remove image',
    my: 'ဓာတ်ပုံဖယ်ရှားပါ'
  },
  generateBtn: {
    en: 'Generate Lesson',
    my: 'သင်ခန်းစာထုတ်လုပ်ပါ'
  },
  generatingBtn: {
    en: 'Generating...',
    my: 'ထုတ်လုပ်နေသည်...'
  },
  inputTab: {
    en: 'Input',
    my: 'ထည့်သွင်းရန်'
  },
  refinementTab: {
    en: 'Refine',
    my: 'ပြုပြင်ရန်'
  },
  deliveryTab: {
    en: 'Deliver',
    my: 'ပို့ချရန်'
  },
  learnersTitle: {
    en: '1. The Learners (Audience)',
    my: '၁။ သင်ယူသူများ (ပရိသတ်)'
  },
  learnersPlaceholder: {
    en: 'Who are the students? (Age range, prior knowledge, experience level). What are their needs and interests? What are their goals? How do they learn best?',
    my: 'ကျောင်းသားများက မည်သူနည်း? (အသက်အရွယ်၊ ကြိုတင်ဗဟုသုတ၊ အတွေ့အကြုံ)။ ၎င်းတို့၏ လိုအပ်ချက်နှင့် စိတ်ဝင်စားမှုများမှာ အဘယ်နည်း? ၎င်းတို့၏ ပန်းတိုင်များမှာ အဘယ်နည်း? ၎င်းတို့ မည်သို့ အကောင်းဆုံး သင်ယူနိုင်သနည်း?'
  },
  outcomesTitle: {
    en: '2. Learning Outcomes and Goals',
    my: '၂။ သင်ယူမှုရလဒ်များနှင့် ပန်းတိုင်များ'
  },
  outcomesPlaceholder: {
    en: 'What should students know or be able to do? What are the key concepts and skills to be addressed? Why is this course important or necessary?',
    my: 'ကျောင်းသားများ ဘာသိသင့်သနည်း သို့မဟုတ် ဘာလုပ်နိုင်သင့်သနည်း? အဓိက သဘောတရားများနှင့် ကျွမ်းကျင်မှုများမှာ အဘယ်နည်း? ဤသင်တန်းသည် အဘယ်ကြောင့် အရေးကြီးသနည်း?'
  },
  structureTitle: {
    en: '3. Content and Structure',
    my: '၃။ အကြောင်းအရာနှင့် ဖွဲ့စည်းပုံ'
  },
  structurePlaceholder: {
    en: 'What content is absolutely essential? How should the content be organized? How will content be revisited? Is the curriculum aligned to standards?',
    my: 'မည်သည့်အကြောင်းအရာက အမှန်တကယ် လိုအပ်သနည်း? အကြောင်းအရာကို မည်သို့ ဖွဲ့စည်းသင့်သနည်း? အကြောင်းအရာကို မည်သို့ ပြန်လည်လေ့လာမည်နည်း? သင်ရိုးညွှန်းတမ်းသည် စံနှုန်းများနှင့် ကိုက်ညီမှုရှိပါသလား?'
  },
  strategiesTitle: {
    en: '4. Teaching and Learning Strategies',
    my: '၄။ သင်ကြားသင်ယူမှု မဟာဗျူဟာများ'
  },
  strategiesPlaceholder: {
    en: 'What methods will engage learners? (Active learning, lectures, discussions, labs). What resources are required? What is the learning environment?',
    my: 'သင်ယူသူများကို မည်သည့်နည်းလမ်းများဖြင့် ဆွဲဆောင်မည်နည်း? (တက်ကြွစွာသင်ယူခြင်း၊ ဟောပြောခြင်း၊ ဆွေးနွေးခြင်း)။ မည်သည့်အရင်းအမြစ်များ လိုအပ်သနည်း? သင်ယူမှုပတ်ဝန်းကျင်မှာ အဘယ်နည်း?'
  },
  assessmentTitle: {
    en: '5. Assessment and Evaluation',
    my: '၅။ အကဲဖြတ်ခြင်းနှင့် စစ်ဆေးခြင်း'
  },
  assessmentPlaceholder: {
    en: 'How will I measure progress? What are the assessment tools? (Quizzes, projects, exams, portfolios). How will I evaluate the curriculum\'s success?',
    my: 'တိုးတက်မှုကို မည်သို့ တိုင်းတာမည်နည်း? အကဲဖြတ်သည့် ကိရိယာများမှာ အဘယ်နည်း? သင်ရိုးညွှန်းတမ်း၏ အောင်မြင်မှုကို မည်သို့ စစ်ဆေးမည်နည်း?'
  },
  equityTitle: {
    en: '6. Accessibility and Equity',
    my: '၆။ လက်လှမ်းမီမှုနှင့် မျှတမှု'
  },
  equityPlaceholder: {
    en: 'Does the curriculum provide "windows and mirrors"? Is there equitable access? Are materials and resources accessible to all learners?',
    my: 'သင်ရိုးညွှန်းတမ်းသည် မတူကွဲပြားသော အမြင်များကို ကိုယ်စားပြုပါသလား? အရင်းအမြစ်များကို သင်ယူသူအားလုံး လက်လှမ်းမီနိုင်ပါသလား?'
  }
};

export const languages: Record<LanguageCode, string> = {
  en: 'English',
  my: 'မြန်မာဘာသာ'
};

export const t = (key: string, lang: LanguageCode): string => {
  return translations[key]?.[lang] || key;
};

export const useTranslation = (lang: LanguageCode) => {
  return (key: string) => t(key, lang);
};
