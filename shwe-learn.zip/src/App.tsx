/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { Sidebar } from './components/Sidebar';
import { InputTab } from './components/InputTab';
import { RefinementTab } from './components/RefinementTab';
import { DeliveryTab } from './components/DeliveryTab';
import { StudentView } from './components/StudentView';
import { AIChatbot } from './components/AIChatbot';
import { generateLessonPlan, adjustLessonPlan } from './lib/gemini';
import { LanguageCode, t } from './lib/i18n';
import { motion, AnimatePresence } from 'motion/react';

export type TabType = 'input' | 'refinement' | 'delivery' | 'chatbot';
export type ViewMode = 'teacher' | 'student';

export interface Student {
  id: string;
  name: string;
  grade: string;
  completedTopics: string[];
  preferredLanguage?: LanguageCode;
  recentScores?: Record<string, { score: number, total: number }>;
  aiRecommendations?: Record<string, { comment: string, proposedAdjustment: string }>;
}

const INITIAL_STUDENTS: Student[] = [
  { id: '1', name: 'Aung Aung', grade: 'Grade 5', completedTopics: ['Math Basics'], preferredLanguage: 'my', recentScores: {} },
  { id: '2', name: 'Su Su', grade: 'Grade 5', completedTopics: ['Math Basics', 'Science'], preferredLanguage: 'my', recentScores: {} },
];

export default function App() {
  const [viewMode, setViewMode] = useState<ViewMode>('teacher');
  const [activeTab, setActiveTab] = useState<TabType>('input');
  const [uiLanguage, setUiLanguage] = useState<LanguageCode>('en');
  const [recentEdits, setRecentEdits] = useState<string[]>([]);
  const [students, setStudents] = useState<Student[]>(INITIAL_STUDENTS);
  const [lastAdjustment, setLastAdjustment] = useState<string | null>(null);
  
  // Persistence
  useEffect(() => {
    const savedStudents = localStorage.getItem('shwe_students');
    if (savedStudents) {
      setStudents(JSON.parse(savedStudents));
    }
    const savedEdits = localStorage.getItem('shwe_recent_edits');
    if (savedEdits) {
      setRecentEdits(JSON.parse(savedEdits));
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('shwe_students', JSON.stringify(students));
  }, [students]);

  useEffect(() => {
    localStorage.setItem('shwe_recent_edits', JSON.stringify(recentEdits));
  }, [recentEdits]);

  const addRecentEdit = (edit: string) => {
    setRecentEdits(prev => [edit, ...prev.slice(0, 4)]);
  };
  const [topic, setTopic] = useState('');
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imageBase64, setImageBase64] = useState<string | null>(null);
  const [imageMimeType, setImageMimeType] = useState<string | null>(null);
  
  // New input fields
  const [learners, setLearners] = useState('');
  const [outcomes, setOutcomes] = useState('');
  const [structure, setStructure] = useState('');
  const [strategies, setStrategies] = useState('');
  const [assessment, setAssessment] = useState('');
  const [equity, setEquity] = useState('');
  
  // State for Refinement Tab
  const [isGenerating, setIsGenerating] = useState(false);
  const [lessonPlan, setLessonPlan] = useState('');
  const [radioScript, setRadioScript] = useState('');
  const [resilienceChecklist, setResilienceChecklist] = useState('');
  const [tags, setTags] = useState<string[]>([]);
  
  // State for Delivery Tab
  const handleGenerate = async () => {
    if (!topic && !imageBase64) return;
    
    setIsGenerating(true);
    setActiveTab('refinement');
    
    try {
      const result = await generateLessonPlan(
        topic, 
        imageBase64 || undefined, 
        imageMimeType || undefined,
        { learners, outcomes, structure, strategies, assessment, equity }
      );
      
      if (result) {
        addRecentEdit(`Generated: ${topic}`);
        // Parse the result based on the delimiter
        const sections = result.split('---SECTION_DIVIDER---');
        if (sections.length >= 3) {
          setLessonPlan(sections[0].trim());
          setRadioScript(sections[1].trim());
          setResilienceChecklist(sections[2].trim());
        } else {
          // Fallback if the model didn't use the delimiter perfectly
          setLessonPlan(result);
        }
      }
    } catch (error) {
      console.error("Error generating lesson plan:", error);
      alert("Failed to generate lesson plan. Please try again.");
    } finally {
      setIsGenerating(false);
    }
  };

  const handleStudentCompleteLesson = (studentId: string, topic: string, score: number, total: number) => {
    setStudents(prev => prev.map(s => {
      if (s.id === studentId) {
        return {
          ...s,
          completedTopics: s.completedTopics.includes(topic) ? s.completedTopics : [...s.completedTopics, topic],
          recentScores: {
            ...(s.recentScores || {}),
            [topic]: { score, total }
          }
        };
      }
      return s;
    }));
  };

  const handleUpdateStudentRecommendation = (studentId: string, topic: string, recommendation: { comment: string, proposedAdjustment: string }) => {
    setStudents(prev => prev.map(s => {
      if (s.id === studentId) {
        return {
          ...s,
          aiRecommendations: {
            ...(s.aiRecommendations || {}),
            [topic]: recommendation
          }
        };
      }
      return s;
    }));
  };

  const handleApplyAdjustment = async (recommendation: string) => {
    setIsGenerating(true);
    setLastAdjustment(recommendation);
    setActiveTab('refinement');
    try {
      const updatedLessonPlan = await adjustLessonPlan(lessonPlan, recommendation);
      setLessonPlan(updatedLessonPlan);
      addRecentEdit(`Adjusted: ${topic}`);
    } catch (error) {
      console.error("Error applying adjustment:", error);
      alert("Failed to apply adjustment. Please try again.");
      setLastAdjustment(null);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="flex h-screen bg-stone-50 font-sans text-stone-900 overflow-hidden">
      <Sidebar 
        activeTab={activeTab} 
        setActiveTab={setActiveTab} 
        uiLanguage={uiLanguage}
        setUiLanguage={setUiLanguage}
        viewMode={viewMode}
        setViewMode={setViewMode}
        recentEdits={recentEdits}
      />
      
      <main className="flex-1 overflow-y-auto relative custom-scrollbar">
        <div className="min-h-full flex flex-col p-2 md:p-4 lg:p-6">
          <div className="flex-1 max-w-[1600px] mx-auto w-full bg-white rounded-[2.5rem] shadow-2xl shadow-gold-900/10 border border-gold-100 overflow-hidden flex flex-col">
            <AnimatePresence mode="wait">
              <motion.div
                key={`${viewMode}-${activeTab}`}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.3, ease: "easeOut" }}
                className="flex-1 flex flex-col"
              >
                {viewMode === 'teacher' ? (
                  <>
                    {activeTab === 'input' && (
                      <InputTab 
                        topic={topic} 
                        setTopic={setTopic}
                        learners={learners}
                        setLearners={setLearners}
                        outcomes={outcomes}
                        setOutcomes={setOutcomes}
                        structure={structure}
                        setStructure={setStructure}
                        strategies={strategies}
                        setStrategies={setStrategies}
                        assessment={assessment}
                        setAssessment={setAssessment}
                        equity={equity}
                        setEquity={setEquity}
                        imageFile={imageFile}
                        setImageFile={setImageFile}
                        setImageBase64={setImageBase64}
                        setImageMimeType={setImageMimeType}
                        onGenerate={handleGenerate}
                        isGenerating={isGenerating}
                        uiLanguage={uiLanguage}
                      />
                    )}
                    
                    {activeTab === 'refinement' && (
                      <RefinementTab 
                        isGenerating={isGenerating}
                        lessonPlan={lessonPlan}
                        setLessonPlan={setLessonPlan}
                        radioScript={radioScript}
                        setRadioScript={setRadioScript}
                        resilienceChecklist={resilienceChecklist}
                        setResilienceChecklist={setResilienceChecklist}
                        topic={topic}
                        setTopic={setTopic}
                        tags={tags}
                        setTags={setTags}
                        onFinalize={() => setActiveTab('delivery')}
                        uiLanguage={uiLanguage}
                        lastAdjustment={lastAdjustment}
                      />
                    )}
                    
                    {activeTab === 'delivery' && (
                      <DeliveryTab 
                        students={students}
                        setStudents={setStudents}
                        currentTopic={topic || 'New Lesson'}
                        uiLanguage={uiLanguage}
                        onUpdateRecommendation={handleUpdateStudentRecommendation}
                        onApplyAdjustment={handleApplyAdjustment}
                      />
                    )}

                    {activeTab === 'chatbot' && (
                      <AIChatbot uiLanguage={uiLanguage} />
                    )}
                  </>
                ) : (
                  <StudentView 
                    students={students}
                    lessonPlan={lessonPlan}
                    topic={topic || 'New Lesson'}
                    uiLanguage={uiLanguage}
                    onCompleteLesson={handleStudentCompleteLesson}
                  />
                )}
              </motion.div>
            </AnimatePresence>
          </div>
          
          <footer className="mt-8 text-center">
            <p className="text-[10px] font-black text-stone-400 uppercase tracking-[0.3em]">
              Shwe Learn • Empowering Education in Myanmar
            </p>
          </footer>
        </div>
      </main>
    </div>
  );
}
