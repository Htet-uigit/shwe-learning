import { useState, useEffect } from 'react';
import { 
  BookOpen, Edit3, QrCode, Sparkles, Globe, GraduationCap, 
  UserCircle, MessageSquare, History, ChevronRight, ChevronLeft, 
  Menu, X, LayoutDashboard, Settings
} from 'lucide-react';
import { TabType, ViewMode } from '../App';
import { LanguageCode, languages, useTranslation } from '../lib/i18n';
import { motion, AnimatePresence } from 'motion/react';

interface SidebarProps {
  activeTab: TabType;
  setActiveTab: (tab: TabType) => void;
  uiLanguage: LanguageCode;
  setUiLanguage: (lang: LanguageCode) => void;
  viewMode: ViewMode;
  setViewMode: (mode: ViewMode) => void;
  recentEdits: string[];
}

const Logo = ({ isCollapsed }: { isCollapsed: boolean }) => (
  <div className={`flex flex-col items-center gap-4 mb-10 transition-all duration-500 ${isCollapsed ? 'px-2' : 'px-6'}`}>
    <div className={`relative flex items-center justify-center transition-all duration-500 ${isCollapsed ? 'w-12 h-12' : 'w-24 h-24'}`}>
      <svg viewBox="0 0 100 100" className="w-full h-full text-gold-500 drop-shadow-2xl">
        <g transform="translate(0, 0)">
          <circle cx="35" cy="32" r="14" fill="none" stroke="currentColor" strokeWidth="6"/>
          <circle cx="65" cy="32" r="14" fill="none" stroke="currentColor" strokeWidth="6"/>
          <path d="M49 32 Q50 26 51 32" fill="none" stroke="currentColor" strokeWidth="6" strokeLinecap="round"/>
        </g>
        <g transform="translate(0, 10)">
          <path d="M20 50 H80 V64 H20 Z" fill="currentColor" rx="4"/>
          <path d="M12 72 H88 V88 H12 Z" fill="currentColor" rx="4"/>
        </g>
      </svg>
    </div>
    {!isCollapsed && (
      <motion.h1 
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-2xl font-black tracking-tight text-white"
      >
        Shwe <span className="text-gold-500">Learn</span>
      </motion.h1>
    )}
  </div>
);

export function Sidebar({ activeTab, setActiveTab, uiLanguage, setUiLanguage, viewMode, setViewMode, recentEdits }: SidebarProps) {
  const [isCollapsed, setIsCollapsed] = useState(true);
  const [isMobileOpen, setIsMobileOpen] = useState(false);
  const t = useTranslation(uiLanguage);

  const tabs = [
    { id: 'input', label: t('inputTab') || 'Input', icon: BookOpen },
    { id: 'refinement', label: t('refinementTab') || 'Refine', icon: Edit3 },
    { id: 'delivery', label: t('deliveryTab') || 'Deliver', icon: QrCode },
    { id: 'chatbot', label: t('aiChatbot') || 'AI Chat', icon: MessageSquare },
  ] as const;

  // Close mobile sidebar on tab change
  const handleTabClick = (tabId: TabType) => {
    setActiveTab(tabId);
    if (window.innerWidth < 1024) {
      setIsMobileOpen(false);
    }
  };

  return (
    <>
      {/* Mobile Menu Toggle */}
      <button 
        onClick={() => setIsMobileOpen(true)}
        className="lg:hidden fixed top-6 left-6 z-50 p-3 bg-stone-900 text-gold-500 rounded-2xl shadow-xl border border-stone-800 hover:scale-110 transition-transform active:scale-95"
      >
        <ChevronRight className="w-6 h-6" />
      </button>

      {/* Mobile Overlay */}
      <AnimatePresence>
        {isMobileOpen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsMobileOpen(false)}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[60] lg:hidden"
          />
        )}
      </AnimatePresence>

      <aside className={`
        fixed inset-y-0 left-0 z-[70] lg:relative lg:z-0
        bg-stone-900 text-stone-400 flex flex-col h-full border-r border-stone-800
        transition-all duration-500 ease-in-out
        ${isCollapsed ? 'w-20' : 'w-64'}
        ${isMobileOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
      `}>
        {/* Desktop Collapse Toggle */}
        <button 
          onClick={() => setIsCollapsed(!isCollapsed)}
          className="hidden lg:flex absolute -right-4 top-12 w-8 h-8 bg-stone-900 border border-stone-800 rounded-full items-center justify-center text-gold-500 hover:text-gold-400 shadow-xl z-10 transition-all hover:scale-125 active:scale-95"
        >
          {isCollapsed ? <ChevronRight className="w-5 h-5" /> : <ChevronLeft className="w-5 h-5" />}
        </button>

        {/* Mobile Close Toggle */}
        <button 
          onClick={() => setIsMobileOpen(false)}
          className="lg:hidden absolute top-6 right-6 p-2 text-stone-500 hover:text-white"
        >
          <X className="w-6 h-6" />
        </button>

        <div className="pt-10">
          <Logo isCollapsed={isCollapsed} />
        </div>

        <div className={`px-4 pb-6 transition-all duration-500 ${isCollapsed ? 'opacity-0 scale-95 pointer-events-none h-0' : 'opacity-100 scale-100'}`}>
          <div className="bg-stone-800/50 rounded-2xl p-1.5 flex items-center border border-stone-700/50">
            <button
              onClick={() => setViewMode('teacher')}
              className={`flex-1 py-2.5 text-xs font-black uppercase tracking-widest rounded-xl transition-all flex items-center justify-center gap-2 ${viewMode === 'teacher' ? 'bg-gold-gradient text-white shadow-lg shadow-gold-900/20' : 'text-stone-500 hover:text-stone-300'}`}
            >
              <UserCircle className="w-4 h-4" />
              Teacher
            </button>
            <button
              onClick={() => setViewMode('student')}
              className={`flex-1 py-2.5 text-xs font-black uppercase tracking-widest rounded-xl transition-all flex items-center justify-center gap-2 ${viewMode === 'student' ? 'bg-gold-gradient text-white shadow-lg shadow-gold-900/20' : 'text-stone-500 hover:text-stone-300'}`}
            >
              <GraduationCap className="w-4 h-4" />
              Student
            </button>
          </div>
        </div>

        <nav className="flex-1 px-4 py-2 space-y-2 overflow-y-auto custom-scrollbar">
          {viewMode === 'teacher' ? (
            <>
              {tabs.map((tab) => {
                const Icon = tab.icon;
                const isActive = activeTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    onClick={() => handleTabClick(tab.id)}
                    className={`w-full group relative flex items-center gap-4 px-4 py-4 rounded-2xl transition-all overflow-hidden ${
                      isActive 
                        ? 'bg-gold-600/10 text-gold-500 font-black' 
                        : 'hover:bg-stone-800/50 hover:text-stone-200'
                    }`}
                  >
                    {isActive && (
                      <motion.div 
                        layoutId="active-tab"
                        className="absolute left-0 top-0 bottom-0 w-1 bg-gold-500 rounded-r-full"
                      />
                    )}
                    <Icon className={`w-6 h-6 transition-colors ${isActive ? 'text-gold-500' : 'text-stone-600 group-hover:text-stone-400'}`} />
                    {!isCollapsed && (
                      <span className="text-sm tracking-tight">{tab.label}</span>
                    )}
                    {isCollapsed && (
                      <div className="absolute left-full ml-4 px-3 py-2 bg-stone-800 text-white text-xs rounded-lg opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity whitespace-nowrap z-50 shadow-2xl border border-stone-700">
                        {tab.label}
                      </div>
                    )}
                  </button>
                );
              })}

              {!isCollapsed && recentEdits.length > 0 && (
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="mt-10 pt-6 border-t border-stone-800/50"
                >
                  <div className="text-[10px] text-stone-600 uppercase tracking-[0.2em] font-black mb-4 flex items-center gap-2 px-4">
                    <History className="w-3.5 h-3.5" /> Recent History
                  </div>
                  <div className="space-y-1 px-2">
                    {recentEdits.map((edit, i) => (
                      <div key={i} className="text-[11px] text-stone-500 px-3 py-2 truncate hover:text-gold-500 transition-colors cursor-default font-medium">
                        {edit}
                      </div>
                    ))}
                  </div>
                </motion.div>
              )}
            </>
          ) : (
            <div className={`px-4 py-12 text-center space-y-6 transition-all duration-500 ${isCollapsed ? 'opacity-0' : 'opacity-100'}`}>
              <div className="w-16 h-16 bg-gold-600/10 rounded-[2rem] flex items-center justify-center mx-auto border border-gold-600/10">
                <GraduationCap className="w-8 h-8 text-gold-600" />
              </div>
              <div>
                <p className="text-stone-200 font-black text-lg tracking-tight">Student Mode</p>
                <p className="mt-2 text-[10px] text-stone-600 uppercase tracking-[0.2em] font-black">Learning Journey</p>
              </div>
            </div>
          )}
        </nav>

        <div className={`p-6 border-t border-stone-800/50 space-y-8 transition-all duration-500 ${isCollapsed ? 'items-center' : ''}`}>
          {!isCollapsed && (
            <div>
              <div className="text-[10px] text-stone-600 uppercase tracking-[0.2em] font-black mb-4 flex items-center gap-2">
                <Globe className="w-3.5 h-3.5" /> Language
              </div>
              <select 
                value={uiLanguage}
                onChange={(e) => setUiLanguage(e.target.value as LanguageCode)}
                className="w-full bg-stone-800/50 border border-stone-700/50 text-stone-300 text-xs font-bold rounded-xl focus:ring-4 focus:ring-gold-500/10 focus:border-gold-500 block p-3 transition-all cursor-pointer appearance-none"
              >
                {Object.entries(languages).map(([code, name]) => (
                  <option key={code} value={code} className="bg-stone-900">{name}</option>
                ))}
              </select>
            </div>
          )}
          
          {viewMode === 'teacher' && !isCollapsed && (
            <div className="bg-gold-600/5 rounded-2xl p-5 border border-gold-600/10 relative overflow-hidden group">
              <div className="absolute top-0 right-0 w-16 h-16 bg-gold-600/10 rounded-full -mr-8 -mt-8 blur-2xl group-hover:bg-gold-600/20 transition-colors" />
              <div className="relative">
                <div className="text-[10px] text-gold-600 uppercase tracking-[0.2em] font-black mb-2 flex items-center gap-2">
                  <Sparkles className="w-3 h-3" /> AI Engine
                </div>
                <div className="text-xs text-stone-400 font-medium">Status: <span className="text-gold-500 font-black">Active</span></div>
              </div>
            </div>
          )}

          {isCollapsed && (
            <div className="flex flex-col items-center gap-6">
              <Globe className="w-6 h-6 text-stone-600 hover:text-gold-500 cursor-pointer transition-colors" />
              <Settings className="w-6 h-6 text-stone-600 hover:text-gold-500 cursor-pointer transition-colors" />
            </div>
          )}
        </div>
      </aside>
    </>
  );
}
