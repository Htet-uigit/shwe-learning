import { useState, useRef, ChangeEvent } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import jsQR from 'jsqr';
import { 
  Check, Download, QrCode, UserPlus, BrainCircuit, Loader2, Sparkles, 
  Search, MessageSquare, ShieldCheck, History, FileText, Scan, Upload,
  Image as ImageIcon, X
} from 'lucide-react';
import { Student } from '../App';
import { LanguageCode, languages, useTranslation } from '../lib/i18n';
import { analyzeStudentResults } from '../lib/gemini';
import { encodeStudentPassport, decodeStudentPassport } from '../lib/qr';
import { exportStudentReport } from '../lib/pdf';

interface DeliveryTabProps {
  students: Student[];
  setStudents: React.Dispatch<React.SetStateAction<Student[]>>;
  currentTopic: string;
  uiLanguage: LanguageCode;
  onUpdateRecommendation: (studentId: string, topic: string, recommendation: { comment: string, proposedAdjustment: string }) => void;
  onApplyAdjustment: (recommendation: string) => void;
}

export function DeliveryTab({ students, setStudents, currentTopic, uiLanguage, onUpdateRecommendation, onApplyAdjustment }: DeliveryTabProps) {
  const [selectedStudentId, setSelectedStudentId] = useState<string | null>(null);
  const [newStudentName, setNewStudentName] = useState('');
  const [newStudentGrade, setNewStudentGrade] = useState('');
  const [newStudentLang, setNewStudentLang] = useState<LanguageCode>('my');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [messageText, setMessageText] = useState('');
  const [isPlagiarismChecking, setIsPlagiarismChecking] = useState(false);
  const [scanInput, setScanInput] = useState('');
  const [showScanner, setShowScanner] = useState(false);
  const [isProcessingQR, setIsProcessingQR] = useState(false);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const t = useTranslation(uiLanguage);

  const selectedStudent = students.find(s => s.id === selectedStudentId) || null;

  const filteredStudents = students.filter(s => 
    s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    s.grade.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleAddStudent = () => {
    if (!newStudentName || !newStudentGrade) return;
    
    const newStudent: Student = {
      id: Math.random().toString(36).substring(7),
      name: newStudentName,
      grade: newStudentGrade,
      completedTopics: [],
      preferredLanguage: newStudentLang
    };
    
    setStudents([...students, newStudent]);
    setNewStudentName('');
    setNewStudentGrade('');
  };

  const handleMarkComplete = (studentId: string) => {
    setStudents(students.map(s => {
      if (s.id === studentId) {
        const updatedTopics = s.completedTopics.includes(currentTopic) 
          ? s.completedTopics 
          : [...s.completedTopics, currentTopic];
        return { ...s, completedTopics: updatedTopics };
      }
      return s;
    }));
  };

  const handleSendMessage = () => {
    if (!messageText.trim() || !selectedStudent) return;
    alert(`Message sent to ${selectedStudent.name}: ${messageText}`);
    setMessageText('');
  };

  const handlePlagiarismCheck = () => {
    setIsPlagiarismChecking(true);
    setTimeout(() => {
      setIsPlagiarismChecking(false);
      alert("Plagiarism Check Complete: 98% Originality. No AI-generated patterns detected.");
    }, 2000);
  };

  const processDecodedQR = (data: string) => {
    const decoded = decodeStudentPassport(data);
    if (decoded) {
      const exists = students.find(s => s.id === decoded.id);
      if (exists) {
        alert("Student already in roster.");
      } else {
        setStudents(prev => [...prev, decoded]);
        alert(`Successfully imported ${decoded.name}'s passport.`);
      }
      setScanInput('');
      setShowScanner(false);
    } else {
      alert("Invalid Passport Data.");
    }
  };

  const handleScanQR = () => {
    processDecodedQR(scanInput);
  };

  const handleFileUpload = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsProcessingQR(true);
    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const context = canvas.getContext('2d');
        if (!context) return;

        canvas.width = img.width;
        canvas.height = img.height;
        context.drawImage(img, 0, 0);

        const imageData = context.getImageData(0, 0, canvas.width, canvas.height);
        const code = jsQR(imageData.data, imageData.width, imageData.height);

        if (code) {
          processDecodedQR(code.data);
        } else {
          alert("Could not find a valid QR code in the image.");
        }
        setIsProcessingQR(false);
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  const handleExportReport = (student: Student) => {
    exportStudentReport(student);
  };

  const handleAnalyzeResults = async (student: Student) => {
    if (!currentTopic) return;
    setIsAnalyzing(true);
    try {
      const score = student.recentScores?.[currentTopic]?.score || 0;
      const total = student.recentScores?.[currentTopic]?.total || 100;
      const result = await analyzeStudentResults(student.name, currentTopic, score, total);
      onUpdateRecommendation(student.id, currentTopic, result);
    } catch (error) {
      console.error("Error analyzing results:", error);
      alert("Failed to analyze results.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="p-4 md:p-8 w-full mx-auto space-y-10 custom-scrollbar">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <h2 className="text-3xl font-bold tracking-tight text-stone-900">
            {t('teacherDashboard')}
          </h2>
          <p className="text-stone-500 font-medium">
            Manage students, track progress, and issue passports.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <button 
            onClick={() => setShowScanner(!showScanner)}
            className="flex items-center gap-2 bg-gold-50 hover:bg-gold-100 text-gold-700 px-5 py-2.5 rounded-xl font-bold border border-gold-200 transition-all shadow-sm"
          >
            <Scan className="w-4 h-4" />
            {t('scanQR')}
          </button>
        </div>
      </header>

      {showScanner && (
        <div className="bg-gold-50 border border-gold-200 rounded-3xl p-8 animate-in fade-in slide-in-from-top-4 shadow-xl shadow-gold-900/5">
          <div className="flex items-center justify-between mb-6">
            <h3 className="font-bold text-gold-900 flex items-center gap-3 uppercase tracking-widest text-sm">
              <QrCode className="w-5 h-5" /> Import Student Passport
            </h3>
            <button 
              onClick={() => fileInputRef.current?.click()}
              disabled={isProcessingQR}
              className="flex items-center gap-2 bg-white hover:bg-gold-50 text-gold-600 px-4 py-2 rounded-xl text-xs font-bold border border-gold-200 transition-all shadow-sm disabled:opacity-50"
            >
              {isProcessingQR ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
              Upload QR Image
            </button>
            <input 
              type="file" 
              ref={fileInputRef} 
              className="hidden" 
              accept="image/*" 
              onChange={handleFileUpload}
            />
          </div>
          
          <div className="flex gap-3">
            <div className="relative flex-1">
              <Scan className="w-5 h-5 absolute left-4 top-1/2 -translate-y-1/2 text-gold-400" />
              <input 
                type="text" 
                placeholder="Paste Base64 Passport String here..."
                value={scanInput}
                onChange={(e) => setScanInput(e.target.value)}
                className="w-full pl-12 pr-5 py-3 bg-white border border-gold-200 rounded-2xl focus:ring-2 focus:ring-gold-500 font-medium"
              />
            </div>
            <button 
              onClick={handleScanQR}
              className="bg-gold-600 text-white px-8 py-3 rounded-2xl font-bold hover:bg-gold-700 transition-all shadow-lg shadow-gold-900/20"
            >
              Import
            </button>
          </div>
          <p className="mt-4 text-[10px] text-gold-600 font-bold uppercase tracking-widest text-center">
            Tip: You can either paste the string or upload an image of the QR code
          </p>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Student List */}
        <div className="lg:col-span-2 space-y-8">
          <div className="bg-white border border-gold-100 rounded-3xl overflow-hidden shadow-xl shadow-gold-900/5">
            <div className="p-8 border-b border-gold-50 bg-gold-50/30 flex flex-col md:flex-row md:items-center justify-between gap-6">
              <div className="flex items-center gap-4">
                <h3 className="font-bold text-stone-800 text-xl">Class Roster</h3>
                <span className="bg-gold-600 text-white text-[10px] font-bold px-4 py-1.5 rounded-full uppercase tracking-widest shadow-md shadow-gold-900/10">
                  {students.length} Students
                </span>
              </div>
              <div className="relative">
                <Search className="w-4 h-4 absolute left-4 top-1/2 -translate-y-1/2 text-gold-400" />
                <input 
                  type="text"
                  placeholder="Search students..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-11 pr-5 py-3 bg-white border border-gold-100 rounded-2xl text-sm focus:ring-2 focus:ring-gold-500 w-full md:w-72 transition-all font-medium"
                />
              </div>
            </div>
            
            <div className="max-h-[600px] overflow-y-auto divide-y divide-gold-50 custom-scrollbar">
              {filteredStudents.map((student) => {
                const isCompleted = student.completedTopics.includes(currentTopic);
                const isSelected = selectedStudent?.id === student.id;
                const recentScore = student.recentScores?.[currentTopic];
                
                return (
                  <div 
                    key={student.id}
                    onClick={() => setSelectedStudentId(student.id)}
                    className={`p-6 flex items-center justify-between cursor-pointer transition-all ${
                      isSelected ? 'bg-gold-50/50' : 'hover:bg-gold-50/20'
                    }`}
                  >
                    <div className="flex items-center gap-5">
                      <div className={`w-12 h-12 rounded-2xl flex items-center justify-center font-bold text-lg shadow-sm transition-all ${
                        isSelected ? 'bg-gold-600 text-white rotate-3' : 'bg-gold-50 text-gold-600'
                      }`}>
                        {student.name.charAt(0)}
                      </div>
                      <div>
                        <p className="font-bold text-stone-900 text-lg">{student.name}</p>
                        <p className="text-sm text-stone-500 font-medium">
                          {student.grade} • {student.completedTopics.length} Topics
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-4">
                      {recentScore && (
                        <span className="text-xs font-bold text-gold-700 bg-gold-100 px-3 py-1.5 rounded-xl border border-gold-200">
                          {recentScore.score}/{recentScore.total}
                        </span>
                      )}
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleMarkComplete(student.id);
                        }}
                        className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                          isCompleted 
                            ? 'bg-gold-600 text-white shadow-md shadow-gold-900/10' 
                            : 'bg-gold-50 text-gold-600 hover:bg-gold-100 border border-gold-100'
                        }`}
                      >
                        <Check className="w-4 h-4" />
                        {isCompleted ? 'Done' : 'Mark'}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {selectedStudent && (
            <div className="bg-white border border-gold-100 rounded-3xl p-8 shadow-xl shadow-gold-900/5 space-y-8 animate-in fade-in zoom-in-95 duration-300 relative">
              <button 
                onClick={() => setSelectedStudentId(null)}
                className="absolute top-6 right-6 p-2 hover:bg-gold-50 rounded-full transition-all text-stone-400 hover:text-gold-600"
              >
                <X className="w-5 h-5" />
              </button>
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-xl text-stone-900 flex items-center gap-3">
                  <History className="w-6 h-6 text-gold-600" />
                  Student Timeline: {selectedStudent.name}
                </h3>
                <button 
                  onClick={() => handleExportReport(selectedStudent)}
                  className="flex items-center gap-2 text-xs font-bold bg-gold-50 hover:bg-gold-100 text-gold-700 px-4 py-2 rounded-xl border border-gold-100 transition-all"
                >
                  <FileText className="w-4 h-4" /> Export Report
                </button>
              </div>

              <div className="relative pl-10 space-y-8 before:absolute before:left-4 before:top-2 before:bottom-2 before:w-0.5 before:bg-gold-100">
                {selectedStudent.completedTopics.length > 0 ? (
                  selectedStudent.completedTopics.map((topic, i) => (
                    <div key={i} className="relative">
                      <div className="absolute -left-10 top-1.5 w-5 h-5 rounded-full bg-gold-600 border-4 border-white shadow-md" />
                      <div>
                        <p className="text-base font-bold text-stone-900">{topic}</p>
                        <p className="text-xs text-stone-500 font-medium">Completed successfully</p>
                      </div>
                    </div>
                  ))
                ) : (
                  <p className="text-sm text-stone-400 italic font-medium">No activity recorded yet.</p>
                )}
              </div>

              <div className="pt-8 border-t border-gold-50 grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-4">
                  <label className="text-[10px] font-bold text-stone-400 uppercase tracking-widest flex items-center gap-2">
                    <MessageSquare className="w-3.5 h-3.5" /> Direct Message
                  </label>
                  <div className="flex gap-2">
                    <input 
                      type="text" 
                      placeholder="Send message to student..."
                      value={messageText}
                      onChange={(e) => setMessageText(e.target.value)}
                      className="flex-1 text-sm px-5 py-3 bg-gold-50/30 border border-gold-100 rounded-2xl focus:ring-2 focus:ring-gold-500 font-medium"
                    />
                    <button 
                      onClick={handleSendMessage}
                      className="bg-gold-600 text-white p-3 rounded-2xl hover:bg-gold-700 transition-all shadow-lg shadow-gold-900/20"
                    >
                      <Sparkles className="w-5 h-5" />
                    </button>
                  </div>
                </div>

                <div className="space-y-4">
                  <label className="text-[10px] font-bold text-stone-400 uppercase tracking-widest flex items-center gap-2">
                    <ShieldCheck className="w-3.5 h-3.5" /> Integrity Check
                  </label>
                  <button 
                    onClick={handlePlagiarismCheck}
                    disabled={isPlagiarismChecking}
                    className="w-full flex items-center justify-center gap-3 bg-stone-900 text-white py-3.5 rounded-2xl text-sm font-bold hover:bg-stone-800 transition-all disabled:opacity-50 shadow-lg"
                  >
                    {isPlagiarismChecking ? <Loader2 className="w-5 h-5 animate-spin" /> : <ShieldCheck className="w-5 h-5" />}
                    Run Plagiarism Check
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Add Student Form */}
          <div className="bg-gold-50/30 border border-gold-100 rounded-3xl p-8">
            <h4 className="font-bold text-stone-800 mb-6 flex items-center gap-3 uppercase tracking-widest text-sm">
              <UserPlus className="w-5 h-5 text-gold-600" />
              {t('addStudent')}
            </h4>
            <div className="flex flex-wrap gap-4">
              <input
                type="text"
                placeholder={t('studentName')}
                value={newStudentName}
                onChange={(e) => setNewStudentName(e.target.value)}
                className="flex-1 min-w-[200px] px-5 py-3.5 bg-white border border-gold-100 rounded-2xl focus:ring-2 focus:ring-gold-500 font-medium"
              />
              <input
                type="text"
                placeholder={t('grade')}
                value={newStudentGrade}
                onChange={(e) => setNewStudentGrade(e.target.value)}
                className="w-28 px-5 py-3.5 bg-white border border-gold-100 rounded-2xl focus:ring-2 focus:ring-gold-500 font-medium"
              />
              <select
                value={newStudentLang}
                onChange={(e) => setNewStudentLang(e.target.value as LanguageCode)}
                className="w-36 px-5 py-3.5 bg-white border border-gold-100 rounded-2xl focus:ring-2 focus:ring-gold-500 font-bold transition-all"
              >
                {Object.entries(languages).map(([code, name]) => (
                  <option key={code} value={code}>{name.split(' ')[0]}</option>
                ))}
              </select>
              <button
                onClick={handleAddStudent}
                disabled={!newStudentName || !newStudentGrade}
                className="bg-gold-600 hover:bg-gold-700 text-white px-8 py-3.5 rounded-2xl font-bold disabled:opacity-50 transition-all shadow-lg shadow-gold-900/20"
              >
                {t('addBtn')}
              </button>
            </div>
          </div>
        </div>

        {/* QR Passport & Analytics Panel */}
        <div className="lg:col-span-1 space-y-8">
          <div className="bg-stone-900 text-white rounded-[2.5rem] p-10 sticky top-8 shadow-2xl border border-stone-800">
            <div className="flex items-center gap-4 mb-10">
              <div className="bg-gold-600/20 p-3 rounded-2xl">
                <QrCode className="w-7 h-7 text-gold-500" />
              </div>
              <h3 className="font-bold text-2xl tracking-tight">{t('passportTitle')}</h3>
            </div>

            {selectedStudent ? (
              <div className="space-y-10 flex flex-col items-center animate-in fade-in slide-in-from-bottom-4 duration-500">
                <div className="text-center space-y-2">
                  <p className="text-3xl font-bold tracking-tight text-gold-500">{selectedStudent.name}</p>
                  <p className="text-stone-400 font-medium uppercase tracking-widest text-xs">{selectedStudent.grade}</p>
                </div>

                <div className="bg-white p-6 rounded-[2rem] shadow-2xl shadow-black/50">
                  <QRCodeSVG 
                    value={encodeStudentPassport(selectedStudent)} 
                    size={220}
                    level="M"
                    includeMargin={false}
                  />
                </div>

                <div className="w-full space-y-6">
                  <div className="bg-white/5 rounded-2xl p-5 border border-white/10">
                    <p className="text-[10px] text-stone-500 uppercase tracking-widest font-bold mb-3">Passport String (Base64)</p>
                    <p className="font-mono text-[10px] text-gold-500/80 break-all leading-relaxed select-all">
                      {encodeStudentPassport(selectedStudent)}
                    </p>
                  </div>
                  
                  <button className="w-full flex items-center justify-center gap-3 bg-gold-600 hover:bg-gold-500 text-white py-4 rounded-2xl font-bold transition-all shadow-lg shadow-gold-900/40">
                    <Download className="w-6 h-6" />
                    {t('downloadPassport')}
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center h-[450px] text-center space-y-6 border-2 border-dashed border-stone-800 rounded-[2rem] p-8">
                <div className="w-20 h-20 bg-stone-800 rounded-3xl flex items-center justify-center text-stone-600">
                  <UserPlus className="w-10 h-10" />
                </div>
                <p className="text-stone-400 font-medium leading-relaxed">Select a student from the roster to generate their offline passport.</p>
              </div>
            )}
          </div>

          {/* AI Analytics Panel */}
          {selectedStudent && selectedStudent.recentScores?.[currentTopic] && (
            <div className="bg-gold-50 border border-gold-200 rounded-[2rem] p-8 shadow-xl shadow-gold-900/5 animate-in fade-in slide-in-from-right-4 duration-500">
              <div className="flex items-center gap-4 mb-6">
                <div className="bg-gold-600 text-white p-3 rounded-2xl shadow-lg shadow-gold-900/20">
                  <BrainCircuit className="w-6 h-6" />
                </div>
                <h3 className="font-bold text-gold-900 text-xl">AI Insights</h3>
              </div>
              
              <div className="mb-6">
                <p className="text-sm text-gold-800 font-bold bg-gold-100/50 px-4 py-2 rounded-xl inline-block">
                  Recent Score: {selectedStudent.recentScores[currentTopic].score}/{selectedStudent.recentScores[currentTopic].total}
                </p>
              </div>

              {selectedStudent.aiRecommendations?.[currentTopic] ? (
                <div className="space-y-6">
                  <div className="bg-white p-6 rounded-2xl border border-gold-100 shadow-sm space-y-4">
                    <div className="space-y-2">
                      <p className="text-[10px] font-bold text-gold-600 uppercase tracking-widest">Teacher Insight</p>
                      <p className="text-sm text-stone-700 leading-relaxed font-medium">
                        {selectedStudent.aiRecommendations[currentTopic].comment}
                      </p>
                    </div>
                    <div className="pt-4 border-t border-gold-50 space-y-2">
                      <p className="text-[10px] font-bold text-gold-600 uppercase tracking-widest">Proposed Curriculum Adjustment</p>
                      <p className="text-sm text-stone-800 font-bold italic">
                        {selectedStudent.aiRecommendations[currentTopic].proposedAdjustment}
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={() => onApplyAdjustment(selectedStudent.aiRecommendations![currentTopic].proposedAdjustment)}
                    className="w-full flex items-center justify-center gap-3 bg-gold-600 hover:bg-gold-700 text-white py-4 rounded-2xl font-bold transition-all shadow-lg shadow-gold-900/20"
                  >
                    <Sparkles className="w-5 h-5" />
                    Apply Adjustment
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => handleAnalyzeResults(selectedStudent)}
                  disabled={isAnalyzing}
                  className="w-full flex items-center justify-center gap-3 bg-gold-600 hover:bg-gold-700 text-white py-4 rounded-2xl font-bold transition-all disabled:opacity-50 shadow-lg shadow-gold-900/20"
                >
                  {isAnalyzing ? <Loader2 className="w-5 h-5 animate-spin" /> : <BrainCircuit className="w-5 h-5" />}
                  Generate Adjustment
                </button>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
