import { ChangeEvent, useRef } from 'react';
import { Camera, FileText, Upload, Loader2, Sparkles, Users, Target, Layout, Lightbulb, ClipboardCheck, Scale, Info } from 'lucide-react';
import { LanguageCode, useTranslation } from '../lib/i18n';
import { motion } from 'motion/react';

interface InputTabProps {
  topic: string;
  setTopic: (topic: string) => void;
  learners: string;
  setLearners: (val: string) => void;
  outcomes: string;
  setOutcomes: (val: string) => void;
  structure: string;
  setStructure: (val: string) => void;
  strategies: string;
  setStrategies: (val: string) => void;
  assessment: string;
  setAssessment: (val: string) => void;
  equity: string;
  setEquity: (val: string) => void;
  imageFile: File | null;
  setImageFile: (file: File | null) => void;
  setImageBase64: (base64: string | null) => void;
  setImageMimeType: (mimeType: string | null) => void;
  onGenerate: () => void;
  isGenerating: boolean;
  uiLanguage: LanguageCode;
}

export function InputTab({
  topic,
  setTopic,
  learners,
  setLearners,
  outcomes,
  setOutcomes,
  structure,
  setStructure,
  strategies,
  setStrategies,
  assessment,
  setAssessment,
  equity,
  setEquity,
  imageFile,
  setImageFile,
  setImageBase64,
  setImageMimeType,
  onGenerate,
  isGenerating,
  uiLanguage
}: InputTabProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const t = useTranslation(uiLanguage);

  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setImageFile(file);
    setImageMimeType(file.type);

    const reader = new FileReader();
    reader.onloadend = () => {
      const base64String = (reader.result as string).split(',')[1];
      setImageBase64(base64String);
    };
    reader.readAsDataURL(file);
  };

  const inputFields = [
    { id: 'learners', label: t('learnersTitle'), value: learners, setter: setLearners, placeholder: t('learnersPlaceholder'), icon: Users },
    { id: 'outcomes', label: t('outcomesTitle'), value: outcomes, setter: setOutcomes, placeholder: t('outcomesPlaceholder'), icon: Target },
    { id: 'structure', label: t('structureTitle'), value: structure, setter: setStructure, placeholder: t('structurePlaceholder'), icon: Layout },
    { id: 'strategies', label: t('strategiesTitle'), value: strategies, setter: setStrategies, placeholder: t('strategiesPlaceholder'), icon: Lightbulb },
    { id: 'assessment', label: t('assessmentTitle'), value: assessment, setter: setAssessment, placeholder: t('assessmentPlaceholder'), icon: ClipboardCheck },
    { id: 'equity', label: t('equityTitle'), value: equity, setter: setEquity, placeholder: t('equityPlaceholder'), icon: Scale },
  ];

  return (
    <div className="p-4 md:p-8 w-full mx-auto space-y-12 custom-scrollbar">
      <motion.header 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="space-y-4 text-center"
      >
        <div className="inline-flex items-center gap-2 px-4 py-2 bg-gold-50 text-gold-600 rounded-full text-xs font-black uppercase tracking-widest border border-gold-100 mb-2">
          <Sparkles className="w-4 h-4" />
          Lesson Architect
        </div>
        <h2 className="text-4xl md:text-5xl font-black tracking-tight text-stone-900">
          {t('createLesson')}
        </h2>
        <p className="text-stone-500 text-lg max-w-2xl mx-auto font-medium">
          {t('createLessonDesc')}
        </p>
      </motion.header>

      <div className="space-y-12">
        {/* Topic Input */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="space-y-4 bg-white p-8 rounded-[2.5rem] border border-gold-100 shadow-2xl shadow-gold-900/5"
        >
          <label htmlFor="topic" className="flex items-center gap-3 text-sm font-black text-stone-900 uppercase tracking-widest">
            <div className="w-8 h-8 bg-gold-100 rounded-lg flex items-center justify-center text-gold-600">
              <FileText className="w-4 h-4" />
            </div>
            {t('lessonTopic')}
          </label>
          <div className="relative group">
            <input
              type="text"
              id="topic"
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              className="block w-full px-8 py-6 bg-stone-50 border-2 border-stone-100 rounded-2xl text-stone-900 placeholder-stone-300 focus:ring-4 focus:ring-gold-500/10 focus:border-gold-500 transition-all text-xl font-bold"
              placeholder={t('topicPlaceholder')}
            />
          </div>
        </motion.div>

        {/* Grid Fields */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {inputFields.map((field, idx) => (
            <motion.div 
              key={field.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
              className="space-y-4 bg-white p-8 rounded-[2.5rem] border border-gold-100 shadow-xl shadow-gold-900/5 hover:shadow-2xl transition-all group"
            >
              <label className="flex items-center gap-3 text-sm font-black text-stone-900 uppercase tracking-widest">
                <div className="w-8 h-8 bg-stone-50 rounded-lg flex items-center justify-center text-stone-400 group-hover:bg-gold-100 group-hover:text-gold-600 transition-colors">
                  <field.icon className="w-4 h-4" />
                </div>
                {field.label}
              </label>
              <textarea
                value={field.value}
                onChange={(e) => field.setter(e.target.value)}
                placeholder={field.placeholder}
                className="w-full p-6 bg-stone-50 border-2 border-stone-100 rounded-2xl text-stone-900 placeholder-stone-300 focus:ring-4 focus:ring-gold-500/10 focus:border-gold-500 transition-all text-sm font-medium min-h-[120px] resize-none"
              />
            </motion.div>
          ))}
        </div>

        {/* Environmental Object Recognition */}
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="space-y-6 bg-stone-900 p-10 rounded-[3rem] text-white shadow-2xl shadow-stone-900/20"
        >
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div className="space-y-2">
              <label className="flex items-center gap-3 text-sm font-black text-gold-500 uppercase tracking-widest">
                <Camera className="w-5 h-5" />
                {t('zeroResourceContext')}
              </label>
              <p className="text-stone-400 text-sm font-medium max-w-md">
                {t('zeroResourceDesc')}
              </p>
            </div>
            <div className="flex items-center gap-2 text-[10px] font-black text-stone-500 uppercase tracking-widest bg-stone-800 px-4 py-2 rounded-full border border-stone-700">
              <Info className="w-3 h-3" /> Visual Context Engine
            </div>
          </div>
          
          <div 
            onClick={() => fileInputRef.current?.click()}
            className={`border-2 border-dashed rounded-[2rem] p-12 text-center cursor-pointer transition-all group ${
              imageFile 
                ? 'border-gold-500 bg-gold-500/10' 
                : 'border-stone-700 hover:border-gold-500 hover:bg-stone-800'
            }`}
          >
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileChange}
              accept="image/*"
              className="hidden"
            />
            
            {imageFile ? (
              <div className="flex flex-col items-center space-y-6">
                <div className="w-24 h-24 bg-gold-gradient rounded-[2rem] flex items-center justify-center text-white shadow-2xl shadow-gold-600/40 relative">
                  <Camera className="w-10 h-10" />
                  <div className="absolute -top-2 -right-2 w-8 h-8 bg-green-500 border-4 border-stone-900 rounded-full flex items-center justify-center">
                    <div className="w-2 h-2 bg-white rounded-full" />
                  </div>
                </div>
                <div>
                  <p className="text-white font-black text-xl tracking-tight">{imageFile.name}</p>
                  <p className="text-gold-500 text-xs font-black uppercase tracking-widest mt-1">
                    {(imageFile.size / 1024 / 1024).toFixed(2)} MB • Ready for Analysis
                  </p>
                </div>
                <button 
                  onClick={(e) => {
                    e.stopPropagation();
                    setImageFile(null);
                    setImageBase64(null);
                    setImageMimeType(null);
                    if (fileInputRef.current) fileInputRef.current.value = '';
                  }}
                  className="px-6 py-2 bg-red-500/10 text-red-500 text-xs font-black uppercase tracking-widest rounded-full hover:bg-red-500 hover:text-white transition-all"
                >
                  {t('removeImage')}
                </button>
              </div>
            ) : (
              <div className="flex flex-col items-center space-y-6">
                <div className="w-24 h-24 bg-stone-800 rounded-[2rem] flex items-center justify-center text-stone-600 group-hover:text-gold-500 group-hover:bg-stone-700 transition-all">
                  <Upload className="w-10 h-10" />
                </div>
                <div>
                  <p className="text-white font-black text-xl tracking-tight">{t('clickToUpload')}</p>
                  <p className="text-stone-500 text-xs font-black uppercase tracking-widest mt-1">{t('uploadLimit')}</p>
                </div>
              </div>
            )}
          </div>
        </motion.div>

        {/* Generate Button */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="pt-12"
        >
          <button
            onClick={onGenerate}
            disabled={(!topic && !imageFile) || isGenerating}
            className="w-full group relative overflow-hidden flex items-center justify-center gap-4 bg-stone-900 text-white py-8 px-12 rounded-[2.5rem] font-black text-2xl transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-2xl shadow-stone-900/40"
          >
            <div className="absolute inset-0 bg-gold-gradient opacity-0 group-hover:opacity-100 transition-opacity" />
            <div className="relative flex items-center gap-4">
              {isGenerating ? (
                <>
                  <Loader2 className="w-8 h-8 animate-spin" />
                  <span className="tracking-tight">{t('generatingBtn')}</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-8 h-8 group-hover:rotate-12 transition-transform" />
                  <span className="tracking-tight">{t('generateBtn')}</span>
                </>
              )}
            </div>
          </button>
          <p className="text-center text-stone-400 text-xs font-black uppercase tracking-[0.2em] mt-6">
            Powered by Gemini 3.1 Pro • Educational Intelligence
          </p>
        </motion.div>
      </div>
    </div>
  );
}
