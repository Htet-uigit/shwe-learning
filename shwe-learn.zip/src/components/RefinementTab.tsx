import { useState, useRef } from 'react';
import { CheckCircle2, Edit3, Radio, ShieldCheck, Loader2, Download, Upload, Globe, FileText, Sparkles, Eye, Code, FileJson, FileType } from 'lucide-react';
import Markdown from 'react-markdown';
import { LanguageCode, languages, useTranslation } from '../lib/i18n';
import { translateContent } from '../lib/gemini';
import { exportCurriculum } from '../lib/pdf';
import { motion, AnimatePresence } from 'motion/react';

interface RefinementTabProps {
  isGenerating: boolean;
  lessonPlan: string;
  setLessonPlan: (plan: string) => void;
  radioScript: string;
  setRadioScript: (script: string) => void;
  resilienceChecklist: string;
  setResilienceChecklist: (checklist: string) => void;
  topic: string;
  setTopic: (topic: string) => void;
  tags: string[];
  setTags: (tags: string[]) => void;
  onFinalize: () => void;
  uiLanguage: LanguageCode;
  lastAdjustment?: string | null;
}

const AVAILABLE_TAGS = ['Math', 'Science', 'Language', 'Safety', 'Health', 'History'];

export function RefinementTab({
  isGenerating,
  lessonPlan,
  setLessonPlan,
  radioScript,
  setRadioScript,
  resilienceChecklist,
  setResilienceChecklist,
  topic,
  setTopic,
  tags,
  setTags,
  onFinalize,
  uiLanguage,
  lastAdjustment
}: RefinementTabProps) {
  const [activeSection, setActiveSection] = useState<'lesson' | 'radio' | 'checklist'>('lesson');
  const [isEditing, setIsEditing] = useState(false);
  const [isTranslating, setIsTranslating] = useState(false);
  const [targetLang, setTargetLang] = useState<LanguageCode>('my');
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const t = useTranslation(uiLanguage);

  const toggleTag = (tag: string) => {
    if (tags.includes(tag)) {
      setTags(tags.filter(t => t !== tag));
    } else {
      setTags([...tags, tag]);
    }
  };

  const handleExportJSON = () => {
    const data = {
      topic,
      tags,
      lessonPlan,
      radioScript,
      resilienceChecklist
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `lesson-${topic.replace(/\s+/g, '-').toLowerCase() || 'export'}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleExportPDF = () => {
    exportCurriculum(topic, lessonPlan, radioScript, resilienceChecklist);
  };

  const handleImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const data = JSON.parse(event.target?.result as string);
        if (data.lessonPlan) setLessonPlan(data.lessonPlan);
        if (data.radioScript) setRadioScript(data.radioScript);
        if (data.resilienceChecklist) setResilienceChecklist(data.resilienceChecklist);
        if (data.topic) setTopic(data.topic);
        if (data.tags) setTags(data.tags);
      } catch (err) {
        alert('Invalid file format');
      }
    };
    reader.readAsText(file);
  };

  const handleTranslate = async () => {
    if (!lessonPlan) return;
    setIsTranslating(true);
    try {
      const targetLanguageName = languages[targetLang];
      const [newLesson, newRadio, newChecklist] = await Promise.all([
        translateContent(lessonPlan, targetLanguageName),
        translateContent(radioScript, targetLanguageName),
        translateContent(resilienceChecklist, targetLanguageName)
      ]);
      setLessonPlan(newLesson);
      setRadioScript(newRadio);
      setResilienceChecklist(newChecklist);
    } catch (e) {
      console.error(e);
      alert('Translation failed');
    } finally {
      setIsTranslating(false);
    }
  };

  if (isGenerating) {
    return (
      <div className="flex flex-col items-center justify-center h-full space-y-8 text-stone-500 min-h-[60vh]">
        <div className="relative">
          <div className="w-24 h-24 border-4 border-gold-100 border-t-gold-600 rounded-full animate-spin" />
          <div className="absolute inset-0 flex items-center justify-center">
            <Sparkles className="w-8 h-8 text-gold-600 animate-pulse" />
          </div>
        </div>
        <div className="text-center space-y-2">
          <p className="text-2xl font-black text-stone-900 uppercase tracking-widest">{t('generatingBtn')}</p>
          <p className="text-stone-400 font-medium italic">Architecting your educational experience...</p>
        </div>
      </div>
    );
  }

  if (!lessonPlan) {
    return (
      <div className="flex flex-col items-center justify-center h-full space-y-8 text-stone-500 min-h-[60vh] p-12 text-center">
        <div className="w-32 h-32 bg-gold-50 rounded-[3rem] flex items-center justify-center text-gold-400 shadow-inner">
          <Edit3 className="w-16 h-16" />
        </div>
        <div className="space-y-2">
          <p className="text-2xl font-black text-stone-900 uppercase tracking-widest">No Content Found</p>
          <p className="text-stone-400 font-medium max-w-sm mx-auto">Start by creating a new lesson or import an existing curriculum file.</p>
        </div>
        <div className="flex items-center gap-4">
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleImport}
            accept=".json"
            className="hidden"
          />
          <button
            onClick={() => fileInputRef.current?.click()}
            className="flex items-center gap-3 px-10 py-5 bg-stone-900 text-white rounded-[2rem] font-black uppercase tracking-widest hover:bg-stone-800 transition-all shadow-2xl shadow-stone-900/20"
          >
            <Upload className="w-5 h-5" />
            {t('importBtn')}
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-8 w-full mx-auto space-y-10 custom-scrollbar">
      <motion.header 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex flex-col md:flex-row md:items-end justify-between gap-8"
      >
        <div className="space-y-4">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-gold-50 text-gold-600 rounded-full text-xs font-black uppercase tracking-widest border border-gold-100">
            <Sparkles className="w-4 h-4" />
            Refinement Studio
          </div>
          <h2 className="text-4xl md:text-5xl font-black tracking-tight text-stone-900">
            {t('refinementTitle')}
          </h2>
          <p className="text-stone-500 text-lg font-medium max-w-2xl">
            {t('refinementDesc')}
          </p>
        </div>
        <button
          onClick={onFinalize}
          className="bg-stone-900 hover:bg-stone-800 text-white px-10 py-6 rounded-[2.5rem] font-black uppercase tracking-widest flex items-center gap-3 transition-all shadow-2xl shadow-stone-900/20 group"
        >
          <CheckCircle2 className="w-6 h-6 group-hover:scale-110 transition-transform" />
          {t('finalizeBtn')}
        </button>
      </motion.header>

      {/* Toolbar */}
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white p-10 rounded-[3rem] border border-gold-100 shadow-2xl shadow-gold-900/5 space-y-10"
      >
        {lastAdjustment && (
          <div className="bg-gold-50 border border-gold-200 p-6 rounded-[2rem] flex items-start gap-4 animate-in fade-in slide-in-from-top-4">
            <div className="w-10 h-10 bg-gold-gradient rounded-xl flex items-center justify-center text-white shrink-0 shadow-lg">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <p className="text-[10px] font-black text-gold-900 uppercase tracking-[0.2em] mb-1">AI Intelligence Applied</p>
              <p className="text-base text-gold-800 font-bold italic">"{lastAdjustment}"</p>
            </div>
          </div>
        )}
        
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-10">
          <div className="space-y-4">
            <span className="text-[10px] font-black text-stone-400 uppercase tracking-[0.2em]">{t('tags')}</span>
            <div className="flex flex-wrap items-center gap-3">
              {AVAILABLE_TAGS.map(tag => (
                <button
                  key={tag}
                  onClick={() => toggleTag(tag)}
                  className={`px-6 py-2.5 rounded-full text-xs font-black uppercase tracking-widest transition-all ${
                    tags.includes(tag) 
                      ? 'bg-gold-600 text-white border-gold-600 shadow-xl shadow-gold-600/20 scale-105' 
                      : 'bg-stone-50 text-stone-400 hover:bg-gold-50 hover:text-gold-600 border-stone-100'
                  } border`}
                >
                  {tag}
                </button>
              ))}
            </div>
          </div>
          
          <div className="space-y-4">
            <span className="text-[10px] font-black text-stone-400 uppercase tracking-[0.2em]">Export & Import</span>
            <div className="flex items-center gap-3">
              <button
                onClick={handleExportJSON}
                className="flex items-center gap-3 px-6 py-3 text-xs font-black uppercase tracking-widest text-stone-600 bg-stone-50 hover:bg-stone-100 rounded-2xl border border-stone-100 transition-all"
              >
                <FileJson className="w-4 h-4" />
                JSON
              </button>
              <button
                onClick={handleExportPDF}
                className="flex items-center gap-3 px-6 py-3 text-xs font-black uppercase tracking-widest text-stone-600 bg-stone-50 hover:bg-stone-100 rounded-2xl border border-stone-100 transition-all"
              >
                <FileType className="w-4 h-4" />
                PDF
              </button>
              <div className="w-px h-8 bg-stone-100 mx-2" />
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleImport}
                accept=".json"
                className="hidden"
              />
              <button
                onClick={() => fileInputRef.current?.click()}
                className="flex items-center gap-3 px-6 py-3 text-xs font-black uppercase tracking-widest text-gold-600 bg-gold-50 hover:bg-gold-100 rounded-2xl border border-gold-100 transition-all"
              >
                <Upload className="w-4 h-4" />
                {t('importBtn')}
              </button>
            </div>
          </div>
        </div>

        <div className="pt-10 border-t border-stone-50 flex flex-col md:flex-row md:items-center gap-6">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-gold-50 rounded-2xl flex items-center justify-center text-gold-500">
              <Globe className="w-6 h-6" />
            </div>
            <div className="space-y-1">
              <p className="text-[10px] font-black text-stone-400 uppercase tracking-widest">Language Translation</p>
              <select
                value={targetLang}
                onChange={(e) => setTargetLang(e.target.value as LanguageCode)}
                className="bg-stone-50 border-none text-stone-900 text-sm rounded-xl focus:ring-4 focus:ring-gold-500/10 p-2.5 font-black uppercase tracking-widest transition-all cursor-pointer"
              >
                {Object.entries(languages).map(([code, name]) => (
                  <option key={code} value={code}>{name}</option>
                ))}
              </select>
            </div>
          </div>
          <button
            onClick={handleTranslate}
            disabled={isTranslating}
            className="flex-1 md:flex-none flex items-center justify-center gap-3 px-10 py-4 bg-gold-600 text-white hover:bg-gold-700 rounded-[2rem] text-sm font-black uppercase tracking-widest transition-all disabled:opacity-50 shadow-xl shadow-gold-600/20"
          >
            {isTranslating ? (
              <><Loader2 className="w-5 h-5 animate-spin" /> {t('translatingBtn')}</>
            ) : (
              <>{t('translateBtn')}</>
            )}
          </button>
        </div>
      </motion.div>

      {/* Section Navigation */}
      <div className="flex flex-wrap gap-4 p-2 bg-stone-100/50 rounded-[2.5rem] border border-stone-100">
        {[
          { id: 'lesson', label: t('lessonPlan'), icon: Edit3 },
          { id: 'radio', label: t('radioScript'), icon: Radio },
          { id: 'checklist', label: t('checklist'), icon: ShieldCheck },
        ].map(section => (
          <button
            key={section.id}
            onClick={() => setActiveSection(section.id as any)}
            className={`flex-1 flex items-center justify-center gap-3 px-8 py-5 rounded-[2rem] font-black text-xs uppercase tracking-widest transition-all ${
              activeSection === section.id
                ? 'bg-white text-gold-600 shadow-xl shadow-gold-900/5'
                : 'text-stone-400 hover:text-stone-600 hover:bg-white/50'
            }`}
          >
            <section.icon className="w-5 h-5" />
            {section.label}
          </button>
        ))}
      </div>

      {/* Content Area */}
      <motion.div 
        key={activeSection}
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        className="bg-white rounded-[3rem] border border-gold-100 overflow-hidden shadow-2xl shadow-gold-900/5"
      >
        <div className="flex items-center justify-between px-10 py-8 bg-stone-50/50 border-b border-gold-100">
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center text-gold-600 shadow-sm">
              {activeSection === 'lesson' && <Edit3 className="w-5 h-5" />}
              {activeSection === 'radio' && <Radio className="w-5 h-5" />}
              {activeSection === 'checklist' && <ShieldCheck className="w-5 h-5" />}
            </div>
            <h3 className="font-black text-stone-900 uppercase tracking-[0.2em] text-sm">
              {activeSection === 'lesson' && t('lessonPlan')}
              {activeSection === 'radio' && t('radioScript')}
              {activeSection === 'checklist' && t('checklist')}
            </h3>
          </div>
          <button
            onClick={() => setIsEditing(!isEditing)}
            className="flex items-center gap-2 text-xs font-black uppercase tracking-widest text-stone-500 hover:text-gold-600 px-6 py-3 rounded-2xl bg-white border border-stone-100 shadow-sm transition-all group"
          >
            {isEditing ? (
              <>
                <Eye className="w-4 h-4 group-hover:scale-110 transition-transform" />
                Preview Mode
              </>
            ) : (
              <>
                <Code className="w-4 h-4 group-hover:scale-110 transition-transform" />
                Edit Content
              </>
            )}
          </button>
        </div>

        <div className="p-10 md:p-16 min-h-[500px] bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] bg-fixed opacity-95">
          <AnimatePresence mode="wait">
            {isEditing ? (
              <motion.textarea
                key="editor"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                value={activeSection === 'lesson' ? lessonPlan : activeSection === 'radio' ? radioScript : resilienceChecklist}
                onChange={(e) => {
                  if (activeSection === 'lesson') setLessonPlan(e.target.value);
                  else if (activeSection === 'radio') setRadioScript(e.target.value);
                  else setResilienceChecklist(e.target.value);
                }}
                className="w-full h-[600px] p-10 bg-stone-50 border-2 border-stone-100 rounded-[2rem] focus:ring-8 focus:ring-gold-500/5 focus:border-gold-500 resize-none font-mono text-base leading-relaxed text-stone-800 custom-scrollbar"
              />
            ) : (
              <motion.div 
                key="preview"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="prose prose-stone max-w-none prose-headings:text-stone-900 prose-headings:font-black prose-headings:uppercase prose-headings:tracking-tight prose-p:text-stone-600 prose-p:leading-loose prose-strong:text-gold-600 prose-ul:list-disc prose-li:text-stone-600"
              >
                <Markdown>
                  {activeSection === 'lesson' ? lessonPlan : activeSection === 'radio' ? radioScript : resilienceChecklist}
                </Markdown>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </motion.div>
    </div>
  );
}
