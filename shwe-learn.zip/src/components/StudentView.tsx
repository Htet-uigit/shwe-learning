import { useState, useMemo } from 'react';
import { 
  BookOpen, Video, Music, FileText, MessageSquare, CheckCircle, 
  PlayCircle, Clock, Award, ChevronRight, PieChart as PieChartIcon,
  CheckCircle2, Send, Loader2, Sparkles, User, HelpCircle, List
} from 'lucide-react';
import { PieChart, Pie, Cell, ResponsiveContainer } from 'recharts';
import { Student } from '../App';
import { LanguageCode, t } from '../lib/i18n';
import Markdown from 'react-markdown';
import { chatWithOfflineAssistant } from '../lib/gemini';

interface StudentViewProps {
  students: Student[];
  lessonPlan: string;
  topic: string;
  uiLanguage: LanguageCode;
  onCompleteLesson: (studentId: string, topic: string, score: number, total: number) => void;
}

type StudentTab = 'dashboard' | 'lesson';
type LessonContentTab = 'video' | 'audio' | 'pdf' | 'discussion' | 'quiz';

export function StudentView({ students, lessonPlan, topic, uiLanguage, onCompleteLesson }: StudentViewProps) {
  const [activeStudentId, setActiveStudentId] = useState<string>(students[0]?.id || '');
  const [activeTab, setActiveTab] = useState<StudentTab>('dashboard');
  const [contentTab, setContentTab] = useState<LessonContentTab>('video');
  const [comments, setComments] = useState<{user: string, text: string}[]>([]);
  const [newComment, setNewComment] = useState('');
  const [chatMessage, setChatMessage] = useState('');
  const [chatHistory, setChatHistory] = useState<{role: 'user' | 'ai', content: string}[]>([
    { role: 'ai', content: 'Hello! I am your AI learning assistant. Do you have any questions about the lesson?' }
  ]);
  const [isChatting, setIsChatting] = useState(false);
  const [quizState, setQuizState] = useState<{
    currentQuestion: number;
    answers: number[];
    isFinished: boolean;
    score: number;
  }>({
    currentQuestion: 0,
    answers: [],
    isFinished: false,
    score: 0
  });

  const currentStudent = students.find(s => s.id === activeStudentId);

  const quizQuestions = useMemo(() => [
    {
      question: `What is the primary concept of ${topic}?`,
      options: ['Option A', 'Option B', 'Option C', 'Option D'],
      correct: 1
    },
    {
      question: `Which of these is a key component of ${topic}?`,
      options: ['Component 1', 'Component 2', 'Component 3', 'Component 4'],
      correct: 0
    },
    {
      question: `How does ${topic} impact the local environment?`,
      options: ['Positively', 'Negatively', 'No impact', 'Depends on usage'],
      correct: 3
    },
    {
      question: `What is the best way to learn ${topic}?`,
      options: ['Reading', 'Watching videos', 'Hands-on practice', 'All of the above'],
      correct: 3
    },
    {
      question: `Who should be involved in ${topic} activities?`,
      options: ['Students', 'Teachers', 'Community', 'Everyone'],
      correct: 3
    }
  ], [topic]);

  const handleQuizAnswer = (optionIndex: number) => {
    const newAnswers = [...quizState.answers, optionIndex];
    if (quizState.currentQuestion < quizQuestions.length - 1) {
      setQuizState({
        ...quizState,
        currentQuestion: quizState.currentQuestion + 1,
        answers: newAnswers
      });
    } else {
      // Calculate score
      const correctCount = newAnswers.reduce((acc, ans, idx) => {
        return acc + (ans === quizQuestions[idx].correct ? 1 : 0);
      }, 0);
      const finalScore = Math.round((correctCount / quizQuestions.length) * 100);
      setQuizState({
        ...quizState,
        answers: newAnswers,
        isFinished: true,
        score: finalScore
      });
    }
  };

  const resetQuiz = () => {
    setQuizState({
      currentQuestion: 0,
      answers: [],
      isFinished: false,
      score: 0
    });
  };

  const progressData = useMemo(() => {
    if (!currentStudent) return [];
    const completed = currentStudent.completedTopics.length;
    const total = 10; // Simulated total courses
    return [
      { name: 'Completed', value: completed },
      { name: 'Remaining', value: total - completed }
    ];
  }, [currentStudent]);

  const COLORS = ['#f59f0a', '#e7e5e4'];

  const handleAddComment = () => {
    if (!newComment.trim() || !currentStudent) return;
    setComments([...comments, { user: currentStudent.name, text: newComment }]);
    setNewComment('');
  };

  const handleSendMessage = async () => {
    if (!chatMessage.trim()) return;
    
    const newHistory = [...chatHistory, { role: 'user' as const, content: chatMessage }];
    setChatHistory(newHistory);
    setChatMessage('');
    setIsChatting(true);
    
    try {
      const response = await chatWithOfflineAssistant(chatMessage, topic, lessonPlan);
      setChatHistory([...newHistory, { role: 'ai', content: response }]);
    } catch (error) {
      console.error("Error chatting with AI:", error);
      setChatHistory([...newHistory, { role: 'ai', content: "I'm having trouble connecting right now. Please try again later." }]);
    } finally {
      setIsChatting(false);
    }
  };

  if (!currentStudent) return <div className="p-8">No student selected.</div>;

  return (
    <div className="flex flex-col h-[calc(100vh-4rem)] bg-gold-50 overflow-hidden">
      {/* Header */}
      <header className="bg-white border-b border-gold-200 px-8 py-4 flex items-center justify-between sticky top-0 z-10">
        <div className="flex items-center gap-4">
          <div className="w-10 h-10 rounded-full bg-gold-600 flex items-center justify-center text-white font-bold">
            {currentStudent.name.charAt(0)}
          </div>
          <div>
            <h2 className="font-semibold text-stone-900">{currentStudent.name}</h2>
            <p className="text-xs text-stone-500">{currentStudent.grade} • Student Passport Active</p>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <select 
            value={activeStudentId}
            onChange={(e) => setActiveStudentId(e.target.value)}
            className="bg-gold-100 border-none text-stone-700 text-sm rounded-lg focus:ring-2 focus:ring-gold-500 p-2"
          >
            {students.map(s => (
              <option key={s.id} value={s.id}>{s.name}</option>
            ))}
          </select>
          <div className="flex items-center gap-2 bg-gold-100 p-1 rounded-xl">
            <button 
              onClick={() => setActiveTab('dashboard')}
              className={`px-4 py-1.5 rounded-lg text-sm font-medium transition-all ${activeTab === 'dashboard' ? 'bg-white text-stone-900 shadow-sm' : 'text-stone-500 hover:text-stone-700'}`}
            >
              Dashboard
            </button>
            <button 
              onClick={() => setActiveTab('lesson')}
              className={`px-4 py-1.5 rounded-lg text-sm font-medium transition-all ${activeTab === 'lesson' ? 'bg-white text-stone-900 shadow-sm' : 'text-stone-500 hover:text-stone-700'}`}
            >
              Lesson
            </button>
          </div>
        </div>
      </header>

      <div className="flex-1 overflow-hidden">
        {activeTab === 'dashboard' ? (
          <div className="h-full overflow-y-auto p-8 space-y-8 custom-scrollbar">
            {/* Stats Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-white p-6 rounded-2xl border border-gold-200 shadow-sm flex items-center gap-4">
                <div className="bg-gold-100 p-3 rounded-xl">
                  <Award className="w-6 h-6 text-gold-600" />
                </div>
                <div>
                  <p className="text-xs text-stone-500 uppercase font-bold tracking-wider">Completed</p>
                  <p className="text-2xl font-bold text-stone-900">{currentStudent.completedTopics.length}</p>
                </div>
              </div>
              <div className="bg-white p-6 rounded-2xl border border-gold-200 shadow-sm flex items-center gap-4">
                <div className="bg-blue-100 p-3 rounded-xl">
                  <Clock className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <p className="text-xs text-stone-500 uppercase font-bold tracking-wider">In Progress</p>
                  <p className="text-2xl font-bold text-stone-900">1</p>
                </div>
              </div>
              <div className="bg-white p-6 rounded-2xl border border-gold-200 shadow-sm flex items-center justify-between">
                <div>
                  <p className="text-xs text-stone-500 uppercase font-bold tracking-wider">Overall Progress</p>
                  <p className="text-2xl font-bold text-stone-900">{Math.round((currentStudent.completedTopics.length / 10) * 100)}%</p>
                </div>
                <div className="w-16 h-16">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={progressData}
                        innerRadius={20}
                        outerRadius={30}
                        paddingAngle={5}
                        dataKey="value"
                      >
                        {progressData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>

            {/* My Courses */}
            <div className="space-y-4">
              <h3 className="text-xl font-bold text-stone-900 flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-gold-600" />
                My Courses
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {/* Active Course */}
                <div 
                  onClick={() => setActiveTab('lesson')}
                  className="bg-white rounded-2xl border-2 border-gold-500 shadow-md overflow-hidden cursor-pointer hover:scale-[1.02] transition-all group"
                >
                  <div className="h-32 bg-gold-600 p-6 flex items-end relative">
                    <div className="absolute top-4 right-4 bg-white/20 backdrop-blur-md px-3 py-1 rounded-full text-[10px] font-bold text-white uppercase tracking-widest">Active</div>
                    <h4 className="text-white font-bold text-xl leading-tight">{topic}</h4>
                  </div>
                  <div className="p-4 space-y-4">
                    <div className="flex items-center justify-between text-xs text-stone-500">
                      <span className="flex items-center gap-1"><PlayCircle className="w-3 h-3" /> 4 Lessons</span>
                      <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> 45 mins</span>
                    </div>
                    <div className="w-full bg-gold-100 h-1.5 rounded-full overflow-hidden">
                      <div className="bg-gold-500 h-full w-1/4" />
                    </div>
                    <button className="w-full py-2 bg-gold-600 text-white rounded-xl text-sm font-bold group-hover:bg-gold-700 transition-colors">Continue Learning</button>
                  </div>
                </div>

                {/* Completed Courses */}
                {currentStudent.completedTopics.map((t, i) => (
                  <div key={i} className="bg-white rounded-2xl border border-gold-200 shadow-sm overflow-hidden opacity-80 grayscale-[0.5]">
                    <div className="h-32 bg-stone-800 p-6 flex items-end relative">
                      <div className="absolute top-4 right-4 bg-gold-500 px-3 py-1 rounded-full text-[10px] font-bold text-white uppercase tracking-widest flex items-center gap-1">
                        <CheckCircle className="w-3 h-3" /> Completed
                      </div>
                      <h4 className="text-white font-bold text-xl leading-tight">{t}</h4>
                    </div>
                    <div className="p-4">
                      <button className="w-full py-2 border border-gold-200 text-stone-600 rounded-xl text-sm font-bold hover:bg-gold-50 transition-colors">Review Content</button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        ) : (
          <div className="h-full flex overflow-hidden">
            {/* Left Sidebar Navigation (Coursera Style) */}
            <div className="w-64 bg-white border-r border-gold-200 flex flex-col shrink-0">
              <div className="p-4 border-b border-gold-100">
                <h3 className="font-bold text-stone-900 text-sm uppercase tracking-wider">Course Content</h3>
              </div>
              <nav className="flex-1 overflow-y-auto p-2 space-y-1">
                <button 
                  onClick={() => setContentTab('video')}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-all ${contentTab === 'video' ? 'bg-gold-50 text-gold-700 font-bold' : 'text-stone-600 hover:bg-stone-50'}`}
                >
                  <Video className={`w-4 h-4 ${contentTab === 'video' ? 'text-gold-600' : 'text-stone-400'}`} />
                  {t('video', uiLanguage)}
                </button>
                <button 
                  onClick={() => setContentTab('audio')}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-all ${contentTab === 'audio' ? 'bg-gold-50 text-gold-700 font-bold' : 'text-stone-600 hover:bg-stone-50'}`}
                >
                  <Music className={`w-4 h-4 ${contentTab === 'audio' ? 'text-gold-600' : 'text-stone-400'}`} />
                  {t('audio', uiLanguage)}
                </button>
                <button 
                  onClick={() => setContentTab('pdf')}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-all ${contentTab === 'pdf' ? 'bg-gold-50 text-gold-700 font-bold' : 'text-stone-600 hover:bg-stone-50'}`}
                >
                  <FileText className={`w-4 h-4 ${contentTab === 'pdf' ? 'text-gold-600' : 'text-stone-400'}`} />
                  {t('pdf', uiLanguage)}
                </button>
                <button 
                  onClick={() => setContentTab('discussion')}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-all ${contentTab === 'discussion' ? 'bg-gold-50 text-gold-700 font-bold' : 'text-stone-600 hover:bg-stone-50'}`}
                >
                  <MessageSquare className={`w-4 h-4 ${contentTab === 'discussion' ? 'text-gold-600' : 'text-stone-400'}`} />
                  {t('discussion', uiLanguage)}
                </button>
                <button 
                  onClick={() => setContentTab('quiz')}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-all ${contentTab === 'quiz' ? 'bg-gold-50 text-gold-700 font-bold' : 'text-stone-600 hover:bg-stone-50'}`}
                >
                  <HelpCircle className={`w-4 h-4 ${contentTab === 'quiz' ? 'text-gold-600' : 'text-stone-400'}`} />
                  {t('quiz', uiLanguage)}
                </button>
              </nav>
              <div className="p-4 border-t border-gold-100">
                <button 
                  onClick={() => {
                    const score = Math.floor(Math.random() * 41) + 60;
                    onCompleteLesson(currentStudent.id, topic, score, 100);
                    setActiveTab('dashboard');
                  }}
                  className="w-full py-3 bg-gold-gradient text-white rounded-xl font-bold text-sm flex items-center justify-center gap-2 hover:opacity-90 transition-all shadow-lg shadow-gold-900/30"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  Finish Lesson
                </button>
              </div>
            </div>

            {/* Main Content Area */}
            <div className="flex-1 flex flex-col overflow-hidden bg-white">
              <div className="flex-1 overflow-y-auto p-8 custom-scrollbar">
                <div className="max-w-5xl mx-auto">
                  <div className="mb-8">
                    <h1 className="text-3xl font-bold text-stone-900 mb-2">{topic}</h1>
                    <div className="flex items-center gap-4 text-sm text-stone-500">
                      <span className="flex items-center gap-1"><Clock className="w-4 h-4" /> 45 mins</span>
                      <span className="flex items-center gap-1"><Award className="w-4 h-4" /> 100 Points</span>
                    </div>
                  </div>

                  {contentTab === 'video' && (
                    <div className="space-y-6">
                      <div className="aspect-video bg-stone-900 rounded-3xl flex items-center justify-center relative overflow-hidden group cursor-pointer">
                        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                        <PlayCircle className="w-20 h-20 text-white opacity-80 group-hover:scale-110 transition-transform" />
                        <div className="absolute bottom-6 left-6 text-white">
                          <p className="text-xs font-bold uppercase tracking-widest opacity-70">Video Lesson</p>
                          <p className="text-xl font-bold">{topic} Explained</p>
                        </div>
                      </div>
                      <div className="prose prose-stone max-w-none">
                        <h3>Lesson Overview</h3>
                        <p>This video covers the fundamental concepts of {topic}. Watch carefully as we use local materials to demonstrate the process.</p>
                      </div>
                    </div>
                  )}

                  {contentTab === 'audio' && (
                    <div className="space-y-6">
                      <div className="bg-stone-900 rounded-3xl p-12 flex flex-col items-center justify-center gap-6 text-white text-center">
                        <div className="w-24 h-24 bg-gold-500 rounded-full flex items-center justify-center animate-pulse">
                          <Music className="w-12 h-12 text-white" />
                        </div>
                        <div>
                          <h4 className="text-2xl font-bold">Audio Guide</h4>
                          <p className="text-stone-400">Perfect for low-bandwidth environments.</p>
                        </div>
                        <div className="w-full max-w-md bg-stone-800 h-2 rounded-full overflow-hidden">
                          <div className="bg-gold-500 h-full w-1/3" />
                        </div>
                        <div className="flex gap-4">
                          <button className="bg-white text-stone-900 px-8 py-3 rounded-full font-bold">Play Audio</button>
                          <button className="bg-stone-800 text-white px-8 py-3 rounded-full font-bold">Download</button>
                        </div>
                      </div>
                    </div>
                  )}

                  {contentTab === 'pdf' && (
                    <div className="space-y-6">
                      <div className="flex items-center justify-between bg-gold-50 p-6 rounded-2xl border border-gold-100">
                        <div className="flex items-center gap-4">
                          <div className="bg-red-100 p-3 rounded-xl">
                            <FileText className="w-8 h-8 text-red-600" />
                          </div>
                          <div>
                            <h4 className="font-bold text-stone-900">Localized Curriculum.pdf</h4>
                            <p className="text-sm text-stone-500">2.4 MB • Available Offline</p>
                          </div>
                        </div>
                        <button className="bg-stone-900 text-white px-6 py-2 rounded-xl font-bold">Download PDF</button>
                      </div>
                      <div className="border border-gold-100 rounded-2xl p-8 prose prose-stone max-w-none bg-gold-50/10">
                        <Markdown>{lessonPlan || "# No lesson plan available yet."}</Markdown>
                      </div>
                    </div>
                  )}

                  {contentTab === 'discussion' && (
                    <div className="space-y-6">
                      <div className="bg-white border border-gold-200 rounded-2xl p-6 space-y-6">
                        <h4 className="font-bold text-lg text-stone-900">Class Discussion</h4>
                        <div className="space-y-4">
                          {comments.length === 0 ? (
                            <p className="text-sm text-stone-400 italic">No comments yet. Be the first to start the discussion!</p>
                          ) : (
                            comments.map((c, i) => (
                              <div key={i} className="flex gap-3">
                                <div className="w-8 h-8 rounded-full bg-gold-100 flex items-center justify-center text-xs font-bold text-gold-700">{c.user.charAt(0)}</div>
                                <div className="bg-gold-50 p-3 rounded-2xl rounded-tl-none flex-1">
                                  <p className="text-xs font-bold text-stone-900 mb-1">{c.user}</p>
                                  <p className="text-sm text-stone-700">{c.text}</p>
                                </div>
                              </div>
                            ))
                          )}
                        </div>
                        <div className="flex gap-3 pt-4 border-t border-gold-100">
                          <input 
                            type="text" 
                            placeholder="Type your question or comment..."
                            value={newComment}
                            onChange={(e) => setNewComment(e.target.value)}
                            onKeyDown={(e) => e.key === 'Enter' && handleAddComment()}
                            className="flex-1 bg-gold-50 border border-gold-200 rounded-xl px-4 py-2 text-sm focus:ring-2 focus:ring-gold-500"
                          />
                          <button 
                            onClick={handleAddComment}
                            className="bg-gold-600 text-white px-6 py-2 rounded-xl text-sm font-bold hover:bg-gold-700 transition-colors"
                          >
                            Post
                          </button>
                        </div>
                      </div>
                    </div>
                  )}

                  {contentTab === 'quiz' && (
                    <div className="space-y-6">
                      <div className="bg-white border border-gold-200 rounded-2xl p-8 space-y-8">
                        <div className="flex items-center justify-between">
                          <h4 className="font-bold text-xl text-stone-900">Lesson Quiz</h4>
                          <span className="text-sm font-medium text-gold-600 bg-gold-50 px-3 py-1 rounded-full">
                            {quizState.isFinished ? 'Completed' : `Question ${quizState.currentQuestion + 1} of ${quizQuestions.length}`}
                          </span>
                        </div>
                        
                        {!quizState.isFinished ? (
                          <div className="space-y-6">
                            <div className="p-6 bg-gold-50/50 rounded-2xl border border-gold-100">
                              <p className="font-bold text-stone-800 mb-6 text-lg">
                                {quizQuestions[quizState.currentQuestion].question}
                              </p>
                              <div className="grid grid-cols-1 gap-3">
                                {quizQuestions[quizState.currentQuestion].options.map((opt, i) => (
                                  <button 
                                    key={i} 
                                    onClick={() => handleQuizAnswer(i)}
                                    className="w-full text-left p-4 bg-white border border-gold-200 rounded-xl text-sm hover:border-gold-500 hover:bg-gold-50 transition-all flex items-center gap-4 group"
                                  >
                                    <div className="w-8 h-8 rounded-full border-2 border-gold-200 flex items-center justify-center text-xs font-bold text-gold-400 group-hover:border-gold-500 group-hover:text-gold-500 group-hover:bg-gold-50">
                                      {String.fromCharCode(65 + i)}
                                    </div>
                                    <span className="font-medium text-stone-700">{opt}</span>
                                  </button>
                                ))}
                              </div>
                            </div>
                          </div>
                        ) : (
                          <div className="text-center py-12 space-y-6">
                            <div className="w-24 h-24 bg-gold-100 rounded-full flex items-center justify-center mx-auto mb-4">
                              <Award className="w-12 h-12 text-gold-600" />
                            </div>
                            <div>
                              <h3 className="text-2xl font-bold text-stone-900">Quiz Completed!</h3>
                              <p className="text-stone-500 mt-2">You scored {quizState.score}% on this quiz.</p>
                            </div>
                            <div className="flex gap-4 justify-center">
                              <button 
                                onClick={resetQuiz}
                                className="px-8 py-3 border border-gold-200 text-stone-700 rounded-xl font-bold hover:bg-gold-50 transition-all"
                              >
                                Retake Quiz
                              </button>
                              <button 
                                onClick={() => {
                                  onCompleteLesson(currentStudent.id, topic, quizState.score, 100);
                                  setActiveTab('dashboard');
                                }}
                                className="px-8 py-3 bg-gold-600 text-white rounded-xl font-bold hover:bg-gold-700 transition-all shadow-lg shadow-gold-200"
                              >
                                Finish Lesson
                              </button>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* AI Assistant Floating Panel (Coursera Style) */}
              <div className="w-80 bg-gold-50 border-l border-gold-200 flex flex-col shrink-0">
                <div className="p-4 border-b border-gold-200 bg-white flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-gold-500" />
                    <h3 className="font-bold text-stone-800 text-sm">AI Tutor</h3>
                  </div>
                </div>
                
                <div className="flex-1 overflow-y-auto p-4 space-y-4 custom-scrollbar">
                  {chatHistory.map((msg, idx) => (
                    <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                      <div className={`max-w-[85%] rounded-2xl p-3 text-xs ${
                        msg.role === 'user' 
                          ? 'bg-gold-600 text-white rounded-tr-none' 
                          : 'bg-white text-stone-800 border border-gold-200 rounded-tl-none'
                      }`}>
                        {msg.content}
                      </div>
                    </div>
                  ))}
                  {isChatting && (
                    <div className="flex justify-start">
                      <div className="bg-white border border-gold-200 text-stone-800 rounded-2xl rounded-tl-none p-3 flex items-center gap-2">
                        <Loader2 className="w-3 h-3 animate-spin text-gold-500" />
                        <span className="text-[10px] text-stone-500">Thinking...</span>
                      </div>
                    </div>
                  )}
                </div>
                
                <div className="p-4 bg-white border-t border-gold-200">
                  <div className="relative">
                    <input
                      type="text"
                      value={chatMessage}
                      onChange={(e) => setChatMessage(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                      placeholder="Ask a question..."
                      className="w-full bg-gold-50 border border-gold-200 rounded-xl pl-4 pr-10 py-3 text-xs focus:ring-2 focus:ring-gold-500 focus:border-gold-500"
                    />
                    <button 
                      onClick={handleSendMessage}
                      disabled={!chatMessage.trim() || isChatting}
                      className="absolute right-2 top-1/2 -translate-y-1/2 p-1.5 text-gold-600 hover:bg-gold-100 rounded-lg disabled:opacity-50 transition-colors"
                    >
                      <Send className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
