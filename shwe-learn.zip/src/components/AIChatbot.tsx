
import { useState, useRef, useEffect } from 'react';
import { 
  Send, Bot, User, Sparkles, Mic, Paperclip, FileText, 
  Loader2, MoreVertical, Trash2, Maximize2, Minimize2,
  Volume2, VolumeX, Info, GraduationCap
} from 'lucide-react';
import { GoogleGenAI } from "@google/genai";
import { LanguageCode, t } from '../lib/i18n';
import { motion, AnimatePresence } from 'motion/react';

interface Message {
  role: 'user' | 'assistant';
  content: string;
  type?: 'text' | 'file' | 'voice';
  fileName?: string;
  timestamp: Date;
}

interface AIChatbotProps {
  uiLanguage: LanguageCode;
}

export function AIChatbot({ uiLanguage }: AIChatbotProps) {
  const [messages, setMessages] = useState<Message[]>([
    { 
      role: 'assistant', 
      content: uiLanguage === 'my' ? 'မင်္ဂလာပါ။ ကျွန်ုပ်သည် သင်၏ AI ပညာရေးလက်ထောက်ဖြစ်ပါသည်။ ဘာများကူညီပေးရမလဲ။' : 'Hello! I am your AI Education Assistant. How can I help you today?', 
      type: 'text',
      timestamp: new Date()
    }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTo({
        top: scrollRef.current.scrollHeight,
        behavior: 'smooth'
      });
    }
  }, [messages, isLoading]);

  const handleSend = async (text: string = input, attachment?: { data: string, mimeType: string, fileName?: string, type: 'file' | 'voice' }) => {
    if (!text.trim() && !attachment) return;
    if (isLoading) return;

    const userMessage = text.trim();
    setInput('');
    
    const newMessage: Message = { 
      role: 'user', 
      content: userMessage || (attachment?.type === 'file' ? `Uploaded file: ${attachment.fileName}` : 'Voice message'), 
      type: attachment?.type || 'text',
      fileName: attachment?.fileName,
      timestamp: new Date()
    };
    
    setMessages(prev => [...prev, newMessage]);
    setIsLoading(true);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const parts: any[] = [];
      
      // Add history (last 10 messages for context)
      messages.slice(-10).forEach(m => {
        if (m.type === 'text') {
          parts.push({ text: m.content });
        }
      });

      // Add current message
      if (userMessage) {
        parts.push({ text: userMessage });
      }

      // Add attachment if any
      if (attachment) {
        parts.push({
          inlineData: {
            data: attachment.data,
            mimeType: attachment.mimeType
          }
        });
      }

      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: [{ role: 'user', parts }],
        config: {
          systemInstruction: `You are a specialized education chatbot for students in Myanmar. 
          Your goal is to help them with their studies, explain complex topics simply, and suggest learning speeds.
          Always be encouraging and patient. 
          The user's preferred language is ${uiLanguage === 'my' ? 'Burmese' : 'English'}. 
          Respond in that language unless asked otherwise.
          Focus on zero-cost learning materials (stones, leaves, sticks) when suggesting activities.
          If the user uploads a file or voice message, analyze it and provide helpful feedback.`
        }
      });

      const aiResponse = response.text || "I've received your input but couldn't generate a text response. How else can I help?";
      setMessages(prev => [...prev, { 
        role: 'assistant', 
        content: aiResponse, 
        type: 'text',
        timestamp: new Date()
      }]);
    } catch (error) {
      console.error("Chatbot error:", error);
      setMessages(prev => [...prev, { 
        role: 'assistant', 
        content: "Sorry, I'm having trouble connecting right now. Please try again later.", 
        type: 'text',
        timestamp: new Date()
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64Data = (reader.result as string).split(',')[1];
        handleSend('', { 
          data: base64Data, 
          mimeType: file.type, 
          fileName: file.name,
          type: 'file'
        });
      };
      reader.readAsDataURL(file);
    }
  };

  const toggleVoiceRecording = async () => {
    if (isRecording) {
      mediaRecorderRef.current?.stop();
      setIsRecording(false);
    } else {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        const mediaRecorder = new MediaRecorder(stream);
        mediaRecorderRef.current = mediaRecorder;
        audioChunksRef.current = [];

        mediaRecorder.ondataavailable = (event) => {
          if (event.data.size > 0) {
            audioChunksRef.current.push(event.data);
          }
        };

        mediaRecorder.onstop = () => {
          const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
          const reader = new FileReader();
          reader.onloadend = () => {
            const base64Data = (reader.result as string).split(',')[1];
            handleSend('', { 
              data: base64Data, 
              mimeType: 'audio/webm', 
              type: 'voice'
            });
          };
          reader.readAsDataURL(audioBlob);
          stream.getTracks().forEach(track => track.stop());
        };

        mediaRecorder.start();
        setIsRecording(true);
      } catch (err) {
        console.error("Error accessing microphone:", err);
        alert("Could not access microphone. Please check permissions.");
      }
    }
  };

  const clearChat = () => {
    if (confirm("Clear all messages?")) {
      setMessages([{ 
        role: 'assistant', 
        content: uiLanguage === 'my' ? 'မင်္ဂလာပါ။ ကျွန်ုပ်သည် သင်၏ AI ပညာရေးလက်ထောက်ဖြစ်ပါသည်။ ဘာများကူညီပေးရမလဲ။' : 'Hello! I am your AI Education Assistant. How can I help you today?', 
        type: 'text',
        timestamp: new Date()
      }]);
    }
  };

  return (
    <div className="flex flex-col h-full bg-stone-50/50">
      {/* Header */}
      <header className="p-6 md:p-8 bg-white border-b border-gold-100 flex items-center justify-between shadow-sm relative z-10">
        <div className="flex items-center gap-5">
          <div className="w-14 h-14 bg-gold-gradient rounded-[1.5rem] flex items-center justify-center text-white shadow-xl shadow-gold-600/20 relative">
            <Bot className="w-8 h-8" />
            <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-500 border-2 border-white rounded-full" />
          </div>
          <div>
            <h2 className="text-2xl font-black text-stone-900 tracking-tight flex items-center gap-2">
              {t('aiChatbot', uiLanguage)}
              <Sparkles className="w-5 h-5 text-gold-500" />
            </h2>
            <div className="flex items-center gap-2 mt-1">
              <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
              <p className="text-xs text-stone-400 font-black uppercase tracking-widest">Educational Engine Active</p>
            </div>
          </div>
        </div>
        
        <div className="flex items-center gap-3">
          <button 
            onClick={() => setIsMuted(!isMuted)}
            className="p-3 text-stone-400 hover:text-gold-600 hover:bg-gold-50 rounded-2xl transition-all"
          >
            {isMuted ? <VolumeX className="w-6 h-6" /> : <Volume2 className="w-6 h-6" />}
          </button>
          <button 
            onClick={clearChat}
            className="p-3 text-stone-400 hover:text-red-600 hover:bg-red-50 rounded-2xl transition-all"
          >
            <Trash2 className="w-6 h-6" />
          </button>
          <div className="h-8 w-px bg-stone-100 mx-2" />
          <button className="p-3 text-stone-400 hover:text-stone-900 hover:bg-stone-50 rounded-2xl transition-all">
            <MoreVertical className="w-6 h-6" />
          </button>
        </div>
      </header>

      {/* Messages Area */}
      <div 
        ref={scrollRef}
        className="flex-1 overflow-y-auto p-6 md:p-10 space-y-10 custom-scrollbar bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] bg-fixed opacity-90"
      >
        <div className="flex flex-col items-center justify-center py-10 text-center space-y-4 opacity-40">
          <div className="w-16 h-16 bg-gold-100 rounded-[2rem] flex items-center justify-center text-gold-600">
            <GraduationCap className="w-8 h-8" />
          </div>
          <div>
            <p className="text-sm font-black uppercase tracking-[0.2em] text-stone-900">Shwe Learn AI</p>
            <p className="text-xs font-medium text-stone-500">Your personal journey to knowledge</p>
          </div>
        </div>

        <AnimatePresence initial={false}>
          {messages.map((m, i) => (
            <motion.div 
              key={i} 
              initial={{ opacity: 0, y: 20, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div className={`flex gap-4 max-w-[85%] md:max-w-[70%] ${m.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
                <div className={`w-12 h-12 rounded-2xl flex items-center justify-center flex-shrink-0 shadow-xl transition-all duration-500 hover:rotate-6 ${
                  m.role === 'user' ? 'bg-white border border-gold-100' : 'bg-gold-gradient'
                }`}>
                  {m.role === 'user' ? <User className="w-6 h-6 text-gold-600" /> : <Bot className="w-6 h-6 text-white" />}
                </div>
                <div className="space-y-2">
                  <div className={`p-6 rounded-[2rem] text-sm md:text-base leading-relaxed shadow-2xl relative group ${
                    m.role === 'user' 
                      ? 'bg-white text-stone-800 rounded-tr-none border border-gold-100 shadow-gold-900/5' 
                      : 'bg-stone-900 text-white rounded-tl-none shadow-stone-900/20 font-medium'
                  }`}>
                    {m.type === 'file' ? (
                      <div className="flex items-center gap-4 bg-stone-800/50 p-4 rounded-2xl border border-white/10">
                        <div className="w-10 h-10 bg-gold-600 rounded-xl flex items-center justify-center text-white">
                          <FileText className="w-6 h-6" />
                        </div>
                        <div>
                          <p className="font-black text-xs uppercase tracking-widest text-gold-500">Attachment</p>
                          <p className="font-bold text-sm truncate max-w-[150px]">{m.fileName}</p>
                        </div>
                      </div>
                    ) : m.type === 'voice' ? (
                      <div className="flex items-center gap-4">
                        <div className="w-10 h-10 bg-gold-600 rounded-xl flex items-center justify-center text-white">
                          <Volume2 className="w-6 h-6" />
                        </div>
                        <p className="font-bold italic">Voice message received</p>
                      </div>
                    ) : (
                      <div className="whitespace-pre-wrap">{m.content}</div>
                    )}
                  </div>
                  <p className={`text-[10px] font-black uppercase tracking-widest text-stone-400 px-2 ${m.role === 'user' ? 'text-right' : 'text-left'}`}>
                    {m.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </p>
                </div>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>

        {isLoading && (
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex justify-start"
          >
            <div className="flex gap-4 items-center">
              <div className="w-12 h-12 rounded-2xl bg-gold-gradient flex items-center justify-center shadow-xl">
                <Bot className="w-6 h-6 text-white animate-pulse" />
              </div>
              <div className="flex gap-2 p-4 bg-white rounded-2xl border border-gold-100 shadow-sm">
                <div className="w-2 h-2 bg-gold-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                <div className="w-2 h-2 bg-gold-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                <div className="w-2 h-2 bg-gold-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
              </div>
            </div>
          </motion.div>
        )}
      </div>

      {/* Input Area */}
      <footer className="p-6 md:p-10 bg-white border-t border-gold-100 relative z-10">
        <div className="max-w-4xl mx-auto space-y-6">
          <div className="flex items-center gap-4 px-4">
            <input 
              type="file" 
              ref={fileInputRef} 
              onChange={handleFileUpload} 
              className="hidden" 
            />
            <button 
              onClick={() => fileInputRef.current?.click()}
              className="p-3 text-stone-400 hover:text-gold-600 hover:bg-gold-50 rounded-2xl transition-all border border-stone-100"
              title="Upload file"
            >
              <Paperclip className="w-6 h-6" />
            </button>
            <button 
              onClick={toggleVoiceRecording}
              className={`p-3 rounded-2xl transition-all border ${
                isRecording 
                  ? 'bg-red-50 text-red-600 border-red-100 animate-pulse' 
                  : 'text-stone-400 hover:text-gold-600 hover:bg-gold-50 border-stone-100'
              }`}
              title={isRecording ? "Stop recording" : "Voice message"}
            >
              <Mic className="w-6 h-6" />
            </button>
            <div className="h-6 w-px bg-stone-100 mx-2" />
            <div className="flex items-center gap-2 text-[10px] font-black text-stone-400 uppercase tracking-widest">
              <Info className="w-3 h-3" /> AI can make mistakes. Verify important info.
            </div>
          </div>

          <div className="flex gap-4">
            <div className="relative flex-1 group">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Ask a question about your studies..."
                className="w-full bg-stone-50 border-2 border-stone-100 rounded-[2rem] px-8 py-5 text-base focus:ring-4 focus:ring-gold-500/10 focus:border-gold-500 transition-all font-bold text-stone-900 placeholder-stone-300"
              />
              <div className="absolute right-6 top-1/2 -translate-y-1/2 flex items-center gap-2 opacity-0 group-focus-within:opacity-100 transition-opacity">
                <span className="text-[10px] font-black text-gold-500 bg-gold-50 px-2 py-1 rounded border border-gold-100">ENTER TO SEND</span>
              </div>
            </div>
            <button
              onClick={() => handleSend()}
              disabled={isLoading || !input.trim()}
              className="bg-stone-900 text-white px-10 rounded-[2rem] hover:bg-stone-800 disabled:opacity-50 disabled:cursor-not-allowed transition-all shadow-2xl shadow-stone-900/20 flex items-center justify-center group"
            >
              <Send className="w-6 h-6 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}
